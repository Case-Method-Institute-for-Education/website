export interface CountyData {
  FIPS: string
  County: string
  value1: string // Number of schools
  value2: string // Number of partner teachers
  value3: string // Number of students
}

// Update the fetchCountyData function to use the new URL
export async function fetchCountyData(): Promise<CountyData[]> {
  try {
    const response = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/schools_2-f7jj8U5HTMGMyDa45mPgFdcJsrm1Qs.csv",
    )
    const csvText = await response.text()

    // Parse CSV
    const lines = csvText.split("\n")
    const headers = lines[0].split(",")

    const data: CountyData[] = []

    for (let i = 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue // Skip empty lines

      const values = lines[i].split(",")
      if (values.length < 5) continue // Skip incomplete lines

      const county: CountyData = {
        FIPS: values[0].trim(),
        County: values[1].trim(),
        value1: values[2].trim(),
        value2: values[3].trim(),
        value3: values[4].trim(),
      }

      data.push(county)
    }

    console.log(`Loaded ${data.length} county records`)
    return data
  } catch (error) {
    console.error("Error fetching or parsing CSV:", error)
    return []
  }
}

// Update the getCountyColor function to use the gold color scheme

// Helper function to get county color based on partner count - using the gold color scheme
export function getCountyColor(count: number): string {
  if (count >= 50) return "#C6A158" // Gold for highest
  if (count >= 25) return "#e69138" // Orange for high
  if (count >= 16) return "#f6b26b" // Light orange for medium-high
  if (count >= 10) return "#f9cb9c" // Peach for medium
  if (count >= 6) return "#ffd966" // Yellow for medium-low
  if (count >= 2) return "#ffe699" // Light yellow for low
  return "#fff2cc" // Very light yellow for very low or zero
}
