import AboutSidebar from "@/components/about-sidebar"

export default function CaseMethodTeaching() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Case Method Teaching</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="sticky top-8">
                <AboutSidebar activePage="case-method" />
              </div>
            </div>

            {/* Main content */}
            <div className="md:w-3/4">
              <div className="prose max-w-none">
                <h2 className="text-3xl font-bold text-paco mb-6">What is Case Method Teaching?</h2>
                <p className="text-gray-700 mb-6">
                  Case method teaching is a form of discussion-based learning that places students at the center of the
                  educational experience. Rather than passively receiving information from a lecturer, students actively
                  engage with rich historical materials, analyzing key decision points and debating different
                  perspectives.
                </p>

                <p className="text-gray-700 mb-6">
                  Originally developed at Harvard Business School, the case method has been adapted for high school
                  history, government, and civics classrooms by the Case Method Institute. Each case presents students
                  with a complex historical situation and asks them to consider the choices facing key decision-makers
                  at critical moments in American history.
                </p>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Benefits for Students</h2>
                <p className="text-gray-700 mb-6">The case method approach offers numerous benefits for students:</p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                  <li>Develops critical thinking and analytical skills</li>
                  <li>Improves verbal communication and argumentation</li>
                  <li>Enhances understanding of historical context and complexity</li>
                  <li>Increases engagement and interest in the subject matter</li>
                  <li>Builds confidence in expressing and defending ideas</li>
                  <li>Fosters respect for diverse perspectives</li>
                </ul>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Benefits for Teachers</h2>
                <p className="text-gray-700 mb-6">
                  Teachers also benefit from implementing the case method in their classrooms:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                  <li>Creates a more dynamic and engaging classroom environment</li>
                  <li>Provides ready-to-use, thoroughly researched teaching materials</li>
                  <li>Offers a structured approach to discussion-based learning</li>
                  <li>Aligns with standards while deepening student understanding</li>
                  <li>Reinvigorates passion for teaching</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
