import AboutSidebar from "@/components/about-sidebar"

export default function Students() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Student Impact</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="sticky top-8">
                <AboutSidebar activePage="students" />
              </div>
            </div>

            {/* Main content */}
            <div className="md:w-3/4">
              <div className="prose max-w-none">
                <h2 className="text-3xl font-bold text-paco mb-6">How Students Benefit</h2>
                <p className="text-gray-700 mb-6">
                  The case method approach has demonstrated significant positive impacts on student learning and
                  engagement. Our research shows that students in case method classrooms experience:
                </p>

                <div className="grid md:grid-cols-2 gap-8 mb-12">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-xl font-bold text-paco mb-4">Academic Growth</h3>
                    <ul className="list-disc pl-6 space-y-2 text-gray-700">
                      <li>Improved critical thinking skills</li>
                      <li>Enhanced content knowledge retention</li>
                      <li>Stronger written and verbal communication</li>
                      <li>Better analytical reasoning</li>
                      <li>Increased historical understanding</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-xl font-bold text-paco mb-4">Civic Development</h3>
                    <ul className="list-disc pl-6 space-y-2 text-gray-700">
                      <li>Greater interest in civic participation</li>
                      <li>Deeper understanding of democratic processes</li>
                      <li>Increased political awareness</li>
                      <li>More nuanced view of complex issues</li>
                      <li>Stronger sense of civic responsibility</li>
                    </ul>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Student Testimonials</h2>

                <div className="space-y-8 mb-12">
                  <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 italic">
                    <p className="text-lg">
                      <span className="text-xl">"</span>Before this class, I never really cared about history or
                      government. But discussing these cases made me realize how important these decisions were and how
                      they still affect us today. Now I actually follow the news and care about what's happening in our
                      democracy.
                      <span className="text-xl">"</span>
                    </p>
                    <p className="text-right font-semibold mt-2">— Miguel, 11th Grade Student</p>
                  </blockquote>

                  <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 italic">
                    <p className="text-lg">
                      <span className="text-xl">"</span>I used to be afraid to speak up in class, but the case
                      discussions helped me find my voice. I learned that my opinions matter and that I can disagree
                      with someone respectfully. These are skills I'll use for the rest of my life.
                      <span className="text-xl">"</span>
                    </p>
                    <p className="text-right font-semibold mt-2">— Jasmine, 12th Grade Student</p>
                  </blockquote>

                  <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 italic">
                    <p className="text-lg">
                      <span className="text-xl">"</span>The case method made history come alive for me. Instead of just
                      memorizing dates and names, we got to step into the shoes of historical figures and understand the
                      tough choices they had to make. It gave me a whole new perspective on how our country was shaped.
                      <span className="text-xl">"</span>
                    </p>
                    <p className="text-right font-semibold mt-2">— Tyler, 10th Grade Student</p>
                  </blockquote>
                </div>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Research Findings</h2>
                <p className="text-gray-700 mb-6">
                  Our ongoing research with partner schools has documented significant improvements in student outcomes.
                  Students in case method classrooms show:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                  <li>30% increase in engagement during class discussions</li>
                  <li>25% improvement in content retention compared to traditional teaching methods</li>
                  <li>Significant gains in critical thinking assessments</li>
                  <li>Greater interest in pursuing further education in history, government, and civics</li>
                  <li>Improved ability to consider multiple perspectives on complex issues</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
