import AboutSidebar from "@/components/about-sidebar"

export default function ProfessionalDevelopment() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Professional Development</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="sticky top-8">
                <AboutSidebar activePage="professional-development" />
              </div>
            </div>

            {/* Main content */}
            <div className="md:w-3/4">
              <div className="prose max-w-none">
                <h2 className="text-3xl font-bold text-paco mb-6">Our Professional Development Program</h2>
                <p className="text-gray-700 mb-6">
                  The Case Method Institute offers comprehensive professional development opportunities for high school
                  teachers of U.S. history, government, and civics. Our program is designed to equip educators with the
                  skills, knowledge, and resources needed to implement case method teaching effectively in their
                  classrooms.
                </p>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">What We Offer</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
                  <li>
                    <strong>Workshops:</strong> Intensive training sessions led by experienced educators
                  </li>
                  <li>
                    <strong>Teaching Materials:</strong> Complete set of case studies and supporting resources
                  </li>
                  <li>
                    <strong>Ongoing Support:</strong> Continued guidance from our teacher support specialists
                  </li>
                  <li>
                    <strong>Community:</strong> Access to a network of like-minded educators
                  </li>
                  <li>
                    <strong>Resources:</strong> Additional materials to enhance classroom implementation
                  </li>
                </ul>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Program Structure</h2>
                <p className="text-gray-700 mb-6">Our professional development program typically includes:</p>
                <ol className="list-decimal pl-6 space-y-2 text-gray-700 mb-6">
                  <li>
                    <strong>Initial Workshop:</strong> A comprehensive introduction to case method teaching
                  </li>
                  <li>
                    <strong>Implementation Phase:</strong> Guided application of the method in your classroom
                  </li>
                  <li>
                    <strong>Follow-up Support:</strong> Ongoing assistance and resources
                  </li>
                  <li>
                    <strong>Advanced Training:</strong> Opportunities for continued growth and development
                  </li>
                </ol>

                <div className="bg-gray-100 p-6 rounded-lg mt-8">
                  <h3 className="text-xl font-bold text-paco mb-4 text-center">Ready to Get Started?</h3>
                  <p className="text-gray-700 mb-4 text-center">
                    All training, teaching materials, and ongoing support are provided entirely free of charge to
                    participant teachers.
                  </p>
                  <div className="text-center">
                    <a
                      href="/opportunities/apply"
                      className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
                    >
                      APPLY NOW
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
