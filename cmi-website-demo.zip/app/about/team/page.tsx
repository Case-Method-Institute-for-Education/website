import AboutSidebar from "@/components/about-sidebar"

export default function Team() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Team</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="sticky top-8">
                <AboutSidebar activePage="team" />
              </div>
            </div>

            {/* Main content */}
            <div className="md:w-3/4">
              <div className="prose max-w-none">
                <h2 className="text-3xl font-bold text-paco mb-6">Leadership</h2>

                <div className="grid md:grid-cols-2 gap-8 mb-12">
                  <div className="text-center">
                    <div className="bg-gray-200 h-64 w-64 mx-auto rounded-full mb-4"></div>
                    <h3 className="text-xl font-bold text-paco">David Moss</h3>
                    <p className="text-gray-600 mb-2">Founder & President</p>
                    <p className="text-gray-700">
                      Professor at Harvard Business School and author of "Democracy: A Case Study"
                    </p>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-64 w-64 mx-auto rounded-full mb-4"></div>
                    <h3 className="text-xl font-bold text-paco">Jane Smith</h3>
                    <p className="text-gray-600 mb-2">Executive Director</p>
                    <p className="text-gray-700">
                      Former high school principal with over 20 years of experience in education
                    </p>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Program Team</h2>

                <div className="grid md:grid-cols-3 gap-8 mb-12">
                  <div className="text-center">
                    <div className="bg-gray-200 h-48 w-48 mx-auto rounded-full mb-4"></div>
                    <h3 className="text-lg font-bold text-paco">Michael Johnson</h3>
                    <p className="text-gray-600 mb-2">Director of Teacher Support</p>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-48 w-48 mx-auto rounded-full mb-4"></div>
                    <h3 className="text-lg font-bold text-paco">Sarah Williams</h3>
                    <p className="text-gray-600 mb-2">Curriculum Developer</p>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-48 w-48 mx-auto rounded-full mb-4"></div>
                    <h3 className="text-lg font-bold text-paco">Robert Chen</h3>
                    <p className="text-gray-600 mb-2">Professional Development Coordinator</p>
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Teacher Support Specialists</h2>

                <div className="grid md:grid-cols-4 gap-6 mb-12">
                  <div className="text-center">
                    <div className="bg-gray-200 h-32 w-32 mx-auto rounded-full mb-3"></div>
                    <h3 className="text-md font-bold text-paco">Emily Davis</h3>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-32 w-32 mx-auto rounded-full mb-3"></div>
                    <h3 className="text-md font-bold text-paco">Marcus Thompson</h3>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-32 w-32 mx-auto rounded-full mb-3"></div>
                    <h3 className="text-md font-bold text-paco">Alicia Rodriguez</h3>
                  </div>

                  <div className="text-center">
                    <div className="bg-gray-200 h-32 w-32 mx-auto rounded-full mb-3"></div>
                    <h3 className="text-md font-bold text-paco">James Wilson</h3>
                  </div>
                </div>

                <div className="bg-gray-100 p-6 rounded-lg mt-8 text-center">
                  <h3 className="text-xl font-bold text-paco mb-4">Join Our Team</h3>
                  <p className="text-gray-700 mb-4">
                    Interested in working with us? Check out our current job openings.
                  </p>
                  <a
                    href="/about/careers"
                    className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
                  >
                    VIEW CAREERS
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
