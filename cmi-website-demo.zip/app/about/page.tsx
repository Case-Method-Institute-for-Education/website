import AboutSidebar from "@/components/about-sidebar"
import D3CountyMap from "@/components/d3-county-map"

export default function About() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="sticky top-28">
                <AboutSidebar activePage="overview" />
              </div>
            </div>

            {/* Main content */}
            <div className="md:w-3/4">
              <div className="prose max-w-none">
                <h2 className="text-3xl font-bold text-paco mb-6">Our Mission</h2>
                <p className="text-gray-700 mb-6">
                  The Case Method Institute for Education and Democracy is dedicated to strengthening student engagement
                  and learning in high school history, government, and civics classrooms through case method teaching,
                  while also preparing young people for active and effective citizenship.
                </p>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Our Approach</h2>
                <p className="text-gray-700 mb-6">
                  Based on the long-standing success of case-method teaching in business and other professional schools,
                  the Case Method Institute has sought to bring case-based teaching to high schools as well. Working
                  with several thousand teachers over recent years, the Institute has convincingly demonstrated that
                  case-based teaching is highly effective in high school education, just as it is in professional
                  education, helping to ensure a more exciting, relevant, and rewarding experience for both students and
                  teachers.
                </p>
                <p className="text-gray-700 mb-6">
                  In particular, teaching history, government, and civics by the case method has been shown to
                  strengthen high school students' academic performance, improving critical thinking, argumentation
                  skills, and even mastery of course content. It also contributes to increasing students' civic
                  interest, knowledge, and engagement, presenting a unique opportunity to help reverse the broad decline
                  in civic education in the United States.
                </p>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Our Team</h2>
                <p className="text-gray-700 mb-6">
                  The Case Method Institute was founded by Professor David Moss of Harvard Business School, drawing on
                  his experience developing and teaching a case-style course on the history of American democracy. The
                  Institute is staffed by a dedicated team of educators, researchers, and administrators committed to
                  improving civic education across the United States.
                </p>

                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Our Impact</h2>
                <p className="text-gray-700 mb-6">
                  Since its founding, the Case Method Institute has worked with thousands of teachers across the United
                  States, reaching tens of thousands of students. Our research has shown that students in case method
                  classrooms demonstrate increased engagement, improved critical thinking skills, and greater interest
                  in civic participation.
                </p>
                <p className="text-gray-700 mb-6">
                  We continue to expand our reach, developing new cases and providing professional development
                  opportunities for teachers across the country, all at no cost to participating schools or teachers.
                </p>
                <h2 className="text-3xl font-bold text-paco mb-6 mt-12">Our National Reach</h2>
                <p className="text-gray-700 mb-6">
                  The Case Method Institute has partnered with teachers across the United States, bringing case method
                  teaching to high school classrooms in nearly every state.
                </p>
                <div className="mb-8 bg-white p-4 rounded-lg shadow-sm text-center overflow-visible">
                  <D3CountyMap />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
