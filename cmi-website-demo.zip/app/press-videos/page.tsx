"use client"

import { useState } from "react"
import VideoCard from "@/components/video-card"
import NewsCard from "@/components/news-card"
import VideoModal from "@/components/video-modal"

type VideoItem = {
  id: number
  title: string
  videoUrl: string
}

type NewsItem = {
  id: number
  title: string
  date: string
  source: string
  excerpt?: string
  url: string
  thumbnail?: string
}

// Initial video data
const videos: VideoItem[] = [
  {
    id: 1,
    title: "Introductory Video: Bringing the Case Method to High Schools",
    videoUrl: "https://vimeo.com/1034793871",
  },
  {
    id: 2,
    title: "Edward M. Kennedy Academy for Health Careers",
    videoUrl: "https://vimeo.com/1034792213",
  },
  {
    id: 3,
    title: "Boston Collegiate Charter School",
    videoUrl: "https://vimeo.com/1034789668",
  },
  {
    id: 4,
    title: "Eleanor Cannon - Houston, TX",
    videoUrl: "https://vimeo.com/1034792891",
  },
  {
    id: 5,
    title: "Maureen O'Hern - Dorchester, MA",
    videoUrl: "https://vimeo.com/1034794729",
  },
  {
    id: 6,
    title: "Michael Gordon - Munster, IN",
    videoUrl: "https://vimeo.com/1034795442",
  },
]

const initialNews: NewsItem[] = [
  {
    id: 1,
    title: "A Better Way to Teach History",
    date: "Feb 8, 2016",
    source: "The Atlantic",
    excerpt:
      "One professor is borrowing a method from Harvard Business School to engage students and inspire better decision-making skills.",
    url: "https://www.theatlantic.com/education/archive/2016/02/harvard-history-class/460314/",
    thumbnail:
      "https://cdn.theatlantic.com/thumbor/Xt9vOLYpYWrLFLEkrqLj-tPjYbs=/0x0:2000x1125/1952x1098/media/img/mt/2016/02/RTR2CKQE/original.jpg",
  },
  {
    id: 2,
    title: "Rewriting History",
    date: "Mar 2, 2016",
    source: "HBS Alumni Bulletin",
    excerpt: "Can one HBS professor change how American history is taught in high schools?",
    url: "https://www.alumni.hbs.edu/stories/Pages/story-impact.aspx?num=5151",
    thumbnail: "https://www.alumni.hbs.edu/PublishingImages/impact/education/moss-david-1200x630.jpg",
  },
  {
    id: 3,
    title: "All Hail Partisan Politics",
    date: "Feb 9, 2017",
    source: "Harvard Gazette",
    excerpt:
      "David Moss spoke with the Gazette about the book and about a new initiative to bring his case studies into dozens of high school classrooms, where they're used as an interactive teaching tool.",
    url: "https://news.harvard.edu/gazette/story/2017/02/all-hail-partisan-politics/",
    thumbnail: "https://news.harvard.edu/wp-content/uploads/2017/02/moss_david_2016_1500x1000-1200x800.jpg",
  },
  {
    id: 4,
    title: "How to Teach Civics in School",
    date: "Jul 6, 2017",
    source: "The Economist",
    excerpt:
      'Inspired by his years using the "case method" developed by Harvard Business School, David Moss has adapted the approach to the study of American democracy.',
    url: "https://www.economist.com/blogs/democracyinamerica/2017/07/civics-lessons",
    thumbnail:
      "https://www.economist.com/sites/default/files/images/2017/07/blogs/democracy-in-america/20170708_usp501.jpg",
  },
  {
    id: 5,
    title: "Making History More Relevant, One Case At A Time",
    date: "May 13, 2019",
    source: "WGBH",
    url: "https://www.wgbh.org/news/education-news/2019-05-13/making-history-more-relevant-one-case-at-a-time",
    thumbnail:
      "https://cdn.wgbh.org/mwa_public_files/styles/x_large/public/mwa-wgbh-media-assets/cms/case_method_institute_classroom_0.jpg",
  },
]

export default function PressVideos() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [currentVideoUrl, setCurrentVideoUrl] = useState("")
  const [news, setNews] = useState<NewsItem[]>(initialNews)

  const openVideoModal = (url: string) => {
    setCurrentVideoUrl(url)
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Press & Videos</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-3xl font-bold text-paco mb-8 text-center">Videos</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {videos.map((video) => (
              <VideoCard
                key={video.id}
                id={video.id}
                title={video.title}
                videoUrl={video.videoUrl}
                onClick={() => openVideoModal(video.videoUrl)}
              />
            ))}
          </div>

          <h2 className="text-3xl font-bold text-paco mb-8 text-center">In the News</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {news.map((item) => (
              <NewsCard
                key={item.id}
                title={item.title}
                date={item.date}
                source={item.source}
                excerpt={item.excerpt}
                url={item.url}
                thumbnail={item.thumbnail}
              />
            ))}
          </div>
        </div>
      </section>
      <VideoModal isOpen={isVideoModalOpen} onClose={closeVideoModal} videoUrl={currentVideoUrl} />
    </>
  )
}
