"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Send, RefreshCw } from "lucide-react"

type FormData = {
  name: string
  email: string
  subject: string
  message: string
  captchaAnswer: string
}

type Captcha = {
  question: string
  answer: number
}

export default function ContactPage() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    subject: "",
    message: "",
    captchaAnswer: "",
  })
  const [captcha, setCaptcha] = useState<Captcha>({ question: "", answer: 0 })
  const [errors, setErrors] = useState<Partial<FormData>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [captchaError, setCaptchaError] = useState("")

  // Generate a simple math captcha
  const generateCaptcha = () => {
    const num1 = Math.floor(Math.random() * 10) + 1
    const num2 = Math.floor(Math.random() * 10) + 1
    const operators = ["+", "-", "×"]
    const operatorIndex = Math.floor(Math.random() * operators.length)
    const operator = operators[operatorIndex]

    let answer = 0
    switch (operator) {
      case "+":
        answer = num1 + num2
        break
      case "-":
        // Ensure we don't have negative answers
        if (num1 >= num2) {
          answer = num1 - num2
        } else {
          answer = num2 - num1
          return { question: `${num2} - ${num1} = ?`, answer }
        }
        break
      case "×":
        answer = num1 * num2
        break
    }

    return { question: `${num1} ${operator} ${num2} = ?`, answer }
  }

  // Generate captcha on component mount
  useEffect(() => {
    setCaptcha(generateCaptcha())
  }, [])

  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha())
    setFormData((prev) => ({ ...prev, captchaAnswer: "" }))
    setCaptchaError("")
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when user types
    if (errors[name as keyof FormData]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }

    // Clear captcha error when user types in captcha field
    if (name === "captchaAnswer" && captchaError) {
      setCaptchaError("")
    }
  }

  const validateForm = () => {
    const newErrors: Partial<FormData> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Name is required"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid"
    }

    if (!formData.subject.trim()) {
      newErrors.subject = "Subject is required"
    }

    if (!formData.message.trim()) {
      newErrors.message = "Message is required"
    }

    if (!formData.captchaAnswer.trim()) {
      newErrors.captchaAnswer = "Please solve the captcha"
    } else if (Number.parseInt(formData.captchaAnswer) !== captcha.answer) {
      setCaptchaError("Incorrect answer, please try again")
      return false
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)

      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
        captchaAnswer: "",
      })

      // Generate new captcha
      refreshCaptcha()
    }, 1500)
  }

  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Contact Us</h1>
          <p className="max-w-2xl mx-auto">
            Have questions about the Case Method Institute or our programs? We're here to help.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <h2 className="text-xl font-bold text-paco mb-4">Contact Information</h2>

                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-gray-700">Address</h3>
                    <p className="text-gray-600">
                      Case Method Institute
                      <br />8 Story Street, Suite 100
                      <br />
                      Cambridge, MA 02138
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-gray-700">Phone</h3>
                    <p className="text-gray-600">1.617.495.0458</p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-gray-700">Email</h3>
                    <p className="text-gray-600">info@cmi.org</p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-gray-700">Office Hours</h3>
                    <p className="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM EST</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:col-span-2">
              {isSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
                  <h3 className="text-2xl font-bold text-green-700 mb-4">Message Sent!</h3>
                  <p className="text-gray-700 mb-6">
                    Thank you for contacting the Case Method Institute. We have received your message and will get back
                    to you as soon as possible.
                  </p>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <div className="bg-white border border-gray-200 rounded-lg p-8 shadow-sm">
                  <h2 className="text-2xl font-bold text-paco mb-6">Send Us a Message</h2>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-paco ${
                          errors.name ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                      {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-paco ${
                          errors.email ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                      {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                    </div>

                    <div>
                      <label htmlFor="subject" className="block text-gray-700 font-medium mb-2">
                        Subject <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-paco ${
                          errors.subject ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                      {errors.subject && <p className="text-red-500 text-sm mt-1">{errors.subject}</p>}
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                        Message <span className="text-red-500">*</span>
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={5}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-paco ${
                          errors.message ? "border-red-500" : "border-gray-300"
                        }`}
                      ></textarea>
                      {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message}</p>}
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg">
                      <label className="block text-gray-700 font-medium mb-2">
                        Verification <span className="text-red-500">*</span>
                      </label>
                      <p className="text-sm text-gray-600 mb-3">
                        Please solve this simple math problem to verify you're human:
                      </p>

                      <div className="flex items-center space-x-3 mb-2">
                        <div className="bg-white px-4 py-2 border border-gray-300 rounded-md font-medium">
                          {captcha.question}
                        </div>
                        <button
                          type="button"
                          onClick={refreshCaptcha}
                          className="p-2 rounded-md bg-gray-200 hover:bg-gray-300 transition-colors"
                          aria-label="Refresh captcha"
                        >
                          <RefreshCw size={18} className="text-gray-700" />
                        </button>
                      </div>

                      <div className="flex items-center space-x-3">
                        <input
                          type="text"
                          id="captchaAnswer"
                          name="captchaAnswer"
                          value={formData.captchaAnswer}
                          onChange={handleChange}
                          placeholder="Your answer"
                          className={`w-32 px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-paco ${
                            errors.captchaAnswer || captchaError ? "border-red-500" : "border-gray-300"
                          }`}
                        />
                        {(errors.captchaAnswer || captchaError) && (
                          <p className="text-red-500 text-sm">{errors.captchaAnswer || captchaError}</p>
                        )}
                      </div>
                    </div>

                    <div className="text-center">
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="bg-navy text-white px-8 py-3 rounded font-medium hover:bg-gold transition-colors inline-flex items-center disabled:opacity-70"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send size={18} className="mr-2" />
                            Send Message
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
