export default function Curriculum() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Curriculum</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-5xl">
          <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 mb-8 max-w-3xl mx-auto italic">
            <p className="text-lg">
              <span className="text-xl">"</span>I think it's very worthwhile to go really deep on history from the angle
              of citizenship and actually [give] kids practice, in the classroom, in the same skills of democratic
              citizenship as they are studying through the cases. So, my classroom becomes a kind of laboratory for
              citizenship.<span className="text-xl">"</span> — <em className="font-semibold">CMI partner teacher</em>
            </p>
          </blockquote>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold text-paco mb-6 text-center">Cases</h2>

              <div className="space-y-8">
                <div>
                  <h4 className="text-xl font-bold text-paco mb-2">
                    James Madison, the 'Federal Negative,' and the Making of the U.S. Constitution (1787)
                  </h4>
                  <p className="text-gray-700 mb-3">
                    This case begins with the American Revolution and concludes at the Constitutional Convention. It
                    describes the many challenges faced by the United States under the Articles of
                    Confederation—including debt, contraction of trade, recession, inflation, and Shays' Rebellion—and
                    how those problems informed key features of the U.S. Constitution.
                  </p>
                  <p className="text-gray-600 italic mb-4">
                    <strong>Coverage:</strong> 1763 – 1787; American Revolution; Articles of Confederation; the
                    'Critical Period'; Shays' Rebellion; James Madison's political theories; majority rule vs. tyranny
                    of the majority; dangers of small republics; "expanding the sphere"; the Constitutional Convention;
                    origins of American federalism, Articles I-III of the U.S. Constitution
                  </p>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-paco mb-2">
                    In Detail: Debt and Paper Money in Rhode Island (1786)
                  </h4>
                  <p className="text-gray-700 mb-3">
                    This short (four-page) case uses an economic dispute between two men in 1780s Rhode Island to offer
                    a more concrete demonstration of how rapid inflation affected debtors and creditors during the
                    Critical Period. It is meant as a supplement to the "James Madison" case above, rather than a
                    standalone case.
                  </p>
                  <p className="text-gray-600 italic mb-4">
                    <strong>Coverage:</strong> Colonial Era – 1786; inflation; debt; paper money
                  </p>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-paco mb-2">
                    Battle Over a Bank: Defining the Limits of Federal Power Under a New Constitution (1791)
                  </h4>
                  <p className="text-gray-700 mb-3">
                    This case covers the first term of George Washington's presidency and the push to ratify the Bill of
                    Rights. It focuses especially on Alexander Hamilton's proposal for a national bank and the question
                    of whether Congress should have powers beyond those explicitly listed in the Constitution.
                  </p>
                  <p className="text-gray-600 italic mb-4">
                    <strong>Coverage:</strong> 1787 – 1791; President Washington; Alexander Hamilton; James Madison;
                    Thomas Jefferson; Federalists vs. Antifederalists; Bill of Rights; implied vs. explicit powers;
                    national debt; First Bank of the United States
                  </p>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-paco mb-2">
                    Democracy, Sovereignty, and the Struggle over Cherokee Removal (1836)
                  </h4>
                  <p className="text-gray-700 mb-3">
                    This case describes how the United States (and its colonial precursors) set policies with respect to
                    Native Americans, from first contact through the presidency of Andrew Jackson. Much of the case is
                    told from the perspective of the Cherokee Nation, as its various political factions lobby for and
                    against the Treaty of New Echota, which, if ratified by the U.S. Senate, would remove the Cherokee
                    from their native lands.
                  </p>
                  <p className="text-gray-600 italic mb-4">
                    <strong>Coverage:</strong> Colonial Era – 1836; history of the Cherokee Nation; President Andrew
                    Jackson; Indian Removal; Trail of Tears
                  </p>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-paco mb-2">
                    Martin Luther King and the Struggle for Black Voting Rights (1965)
                  </h4>
                  <p className="text-gray-700 mb-3">
                    This case traces the long history of black disenfranchisement and racial segregation in the United
                    States, from the Reconstruction Era to the 1960s. It describes the various strategies employed by
                    civil rights activists, with a special emphasis on the civil disobedience protests of the modern
                    Civil Rights Movement, and culminates in Martin Luther King's decision of whether to lead protesters
                    across Pettus Bridge on the famous protest march starting in Selma, Alabama on March 9, 1965.
                  </p>
                  <p className="text-gray-600 italic mb-4">
                    <strong>Coverage:</strong> 1865 – 1965; racial segregation; Jim Crow; black disenfranchisement; poll
                    taxes; literacy tests; white primaries; grandfather clauses; NAACP; Plessy v. Ferguson; Brown v.
                    Board of Education; Martin Luther King, Jr.; Civil Rights Movement; Freedom Rides; Children's March;
                    President John F. Kennedy; President Lyndon B. Johnson; Civil Rights Act of 1964; Selma; Montgomery;
                    Birmingham; Voting Rights Act of 1965
                  </p>
                </div>
              </div>
            </div>

            <div>
              <div className="bg-navy text-white p-6 rounded-lg mb-8">
                <p className="font-bold mb-4 text-center">INTERESTED IN BECOMING A PARTNER TEACHER?</p>
                <div className="text-center">
                  <a
                    href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-gold text-white px-4 py-2 rounded font-medium hover:bg-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 inline-block"
                  >
                    APPLY FOR OUR PD PROGRAM
                  </a>
                </div>
              </div>

              <div className="border border-gray-200 p-6 rounded-lg">
                <h5 className="text-xl font-bold text-paco mb-4 text-center">ALREADY A TEACHING PARTNER?</h5>
                <p className="text-gray-700 mb-4 text-center">
                  If you are already working with the Case Method Institute you may download all case materials directly
                  via{" "}
                  <a
                    href="https://www.sharevault.net/documents?svid=5107"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cherrywood hover:underline"
                  >
                    ShareVault
                  </a>
                  .
                </p>
                <div className="text-center">
                  <a
                    href="https://www.sharevault.net/documents?svid=5107"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cherrywood hover:underline flex items-center justify-center"
                  >
                    <span className="mr-2">→</span> Login to ShareVault
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
