import Link from "next/link"
import { ArrowRight, Users, BookOpen, Calendar } from "lucide-react"

export default function Opportunities() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Opportunities for Teachers</h1>
          <p className="max-w-3xl mx-auto text-white/80 text-lg">
            Join our community of educators and transform your classroom with case method teaching
          </p>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-paco mb-6">Join Our Community of Educators</h2>
            <p className="text-gray-700 mb-8 max-w-3xl mx-auto">
              The Case Method Institute offers various opportunities for high school teachers of U.S. history,
              government, and civics. Explore the options below to find the right fit for you.
            </p>
          </div>

          <div className="space-y-8">
            {/* Partner Teachers Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg group">
              <div className="md:flex">
                <div className="md:w-1/3 bg-gradient-to-br from-navy to-paco p-6 text-white flex flex-col justify-center items-center md:items-start">
                  <Users className="h-12 w-12 mb-4 text-gold" />
                  <h3 className="text-2xl font-bold mb-2 text-center md:text-left">Partner Teachers</h3>
                  <p className="text-white/80 text-center md:text-left">Join our nationwide network of educators</p>
                </div>
                <div className="md:w-2/3 p-6 md:p-8">
                  <p className="text-gray-700 mb-6">
                    Join more than 4,000 teachers from across the country who have attended our professional development
                    workshops and are implementing case method teaching in their classrooms. Everything – including the
                    PD workshops, cases, teaching materials, and ongoing support – is provided free of charge.
                  </p>
                  <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                    <Link
                      href="/opportunities/partners"
                      className="bg-navy text-white px-5 py-2.5 rounded-full font-medium hover:bg-paco transition-colors inline-block"
                    >
                      Learn More
                    </Link>
                    <a
                      href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-gold text-white px-5 py-2.5 rounded-full font-medium hover:bg-cherrywood transition-colors inline-flex items-center"
                    >
                      Apply Now <ArrowRight className="ml-2 h-4 w-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Mailing List Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg group">
              <div className="md:flex">
                <div className="md:w-1/3 bg-gradient-to-br from-cherrywood to-paco p-6 text-white flex flex-col justify-center items-center md:items-start">
                  <BookOpen className="h-12 w-12 mb-4 text-gold" />
                  <h3 className="text-2xl font-bold mb-2 text-center md:text-left">Join Mailing List</h3>
                  <p className="text-white/80 text-center md:text-left">Stay updated with the latest resources</p>
                </div>
                <div className="md:w-2/3 p-6 md:p-8">
                  <p className="text-gray-700 mb-6">
                    Stay updated with the latest news, resources, and opportunities from the Case Method Institute. Our
                    newsletter includes teaching tips, case study highlights, upcoming events, and success stories from
                    classrooms across the country.
                  </p>
                  <div className="flex justify-center md:justify-start">
                    <Link
                      href="/opportunities/mailing-list"
                      className="bg-navy text-white px-5 py-2.5 rounded-full font-medium hover:bg-paco transition-colors inline-block"
                    >
                      Sign Up
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            {/* Future Opportunities Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg group">
              <div className="md:flex">
                <div className="md:w-1/3 bg-gradient-to-br from-gold to-cherrywood p-6 text-white flex flex-col justify-center items-center md:items-start">
                  <Calendar className="h-12 w-12 mb-4 text-white" />
                  <h3 className="text-2xl font-bold mb-2 text-center md:text-left">Future Opportunities</h3>
                  <p className="text-white/80 text-center md:text-left">Discover upcoming events and programs</p>
                </div>
                <div className="md:w-2/3 p-6 md:p-8">
                  <p className="text-gray-700 mb-6">
                    Learn about upcoming workshops, events, and other opportunities for professional growth. The Case
                    Method Institute regularly offers specialized training sessions, advanced workshops, regional
                    meetups, and collaborative teaching opportunities.
                  </p>
                  <div className="flex justify-center md:justify-start">
                    <Link
                      href="/opportunities/future"
                      className="bg-navy text-white px-5 py-2.5 rounded-full font-medium hover:bg-paco transition-colors inline-block"
                    >
                      Explore
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial */}
          <div className="mt-16 bg-gray-50 rounded-xl p-8 shadow-inner">
            <blockquote className="text-center">
              <p className="text-lg text-gray-700 italic mb-4">
                <span className="text-3xl text-gold">"</span>
                The Case Method Institute's professional development program transformed my teaching approach
                completely. My students are more engaged, thinking critically, and developing a genuine interest in
                history and civics.
                <span className="text-3xl text-gold">"</span>
              </p>
              <footer className="text-gray-600">
                <strong>Maria Rodriguez</strong> — History Teacher, Chicago, IL
              </footer>
            </blockquote>
          </div>
        </div>
      </section>
    </>
  )
}
