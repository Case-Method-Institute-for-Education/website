"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"

export default function Apply() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    school: "",
    position: "",
    subject: "",
    experience: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
      setFormData({
        name: "",
        email: "",
        school: "",
        position: "",
        subject: "",
        experience: "",
        message: "",
      })
    }, 1500)
  }

  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Apply to Become a Partner Teacher</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-paco mb-6">Join Our Program</h2>
            <p className="text-gray-700 mb-6 max-w-3xl mx-auto">
              The Case Method Institute invites high school teachers of U.S. history, government, and civics to apply to
              our professional development program. All training, teaching materials, and ongoing support are provided
              entirely free of charge to participant teachers.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-paco mb-4">Eligibility</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>High school teachers of U.S. history, government, or civics</li>
                <li>Commitment to implementing case method teaching</li>
                <li>Interest in strengthening students' critical thinking and civic engagement</li>
              </ul>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-paco mb-4">What You'll Receive</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Free professional development workshops</li>
                <li>Complete set of case materials</li>
                <li>Ongoing support from teacher specialists</li>
                <li>Access to a community of educators</li>
              </ul>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-paco mb-4">Time Commitment</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Initial 2-day workshop</li>
                <li>Implementation of at least one case per semester</li>
                <li>Participation in follow-up support sessions</li>
                <li>Brief feedback surveys</li>
              </ul>
            </div>
          </div>

          {isSubmitted ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
              <h3 className="text-2xl font-bold text-green-700 mb-4">Application Received!</h3>
              <p className="text-gray-700 mb-6">
                Thank you for your interest in becoming a partner teacher with the Case Method Institute. We have
                received your application and will be in touch with you soon.
              </p>
              <Link
                href="/"
                className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
              >
                Return to Homepage
              </Link>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-lg p-8">
              <h3 className="text-2xl font-bold text-paco mb-6 text-center">Application Form</h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="school" className="block text-gray-700 font-medium mb-2">
                      School Name *
                    </label>
                    <input
                      type="text"
                      id="school"
                      name="school"
                      value={formData.school}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                    />
                  </div>

                  <div>
                    <label htmlFor="position" className="block text-gray-700 font-medium mb-2">
                      Position *
                    </label>
                    <input
                      type="text"
                      id="position"
                      name="position"
                      value={formData.position}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="subject" className="block text-gray-700 font-medium mb-2">
                    Subject(s) Taught *
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  />
                </div>

                <div>
                  <label htmlFor="experience" className="block text-gray-700 font-medium mb-2">
                    Years of Teaching Experience *
                  </label>
                  <select
                    id="experience"
                    name="experience"
                    value={formData.experience}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  >
                    <option value="">Select years of experience</option>
                    <option value="0-2">0-2 years</option>
                    <option value="3-5">3-5 years</option>
                    <option value="6-10">6-10 years</option>
                    <option value="11-15">11-15 years</option>
                    <option value="16+">16+ years</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                    Why are you interested in case method teaching? *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  ></textarea>
                </div>

                <div className="text-center">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-navy text-white px-8 py-3 rounded font-medium hover:bg-gold transition-colors inline-block disabled:opacity-70"
                    onClick={() => {
                      if (!isSubmitting) {
                        window.open("https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU", "_blank")
                      }
                    }}
                  >
                    {isSubmitting ? "Submitting..." : "Submit Application"}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </section>
    </>
  )
}
