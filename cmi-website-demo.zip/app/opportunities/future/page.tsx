"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"

type Opportunity = {
  id: number
  title: string
  date: string
  location: string
  description: string
}

const opportunities: Opportunity[] = [
  {
    id: 1,
    title: "Summer Workshop Series",
    date: "June 15-30, 2025",
    location: "Virtual",
    description:
      "A series of online workshops covering various aspects of case method teaching, including facilitation techniques, assessment strategies, and adapting cases for different student populations.",
  },
  {
    id: 2,
    title: "Advanced Case Method Teaching Institute",
    date: "July 10-12, 2025",
    location: "Cambridge, MA",
    description:
      "An intensive in-person workshop for experienced case method teachers looking to deepen their practice and explore advanced facilitation techniques.",
  },
  {
    id: 3,
    title: "Regional Teacher Meetups",
    date: "Fall 2025",
    location: "Various Locations",
    description:
      "Connect with other case method teachers in your region to share experiences, strategies, and build a local community of practice.",
  },
]

export default function FutureOpportunities() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    interests: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
      setFormData({
        name: "",
        email: "",
        interests: "",
      })
    }, 1500)
  }

  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Future Opportunities</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-paco mb-6">Upcoming Programs & Events</h2>
            <p className="text-gray-700 mb-6 max-w-3xl mx-auto">
              Explore upcoming opportunities for professional development, collaboration, and growth with the Case
              Method Institute. Check back regularly as new opportunities are added throughout the year.
            </p>
          </div>

          <div className="space-y-8 mb-16">
            {opportunities.map((opportunity) => (
              <div
                key={opportunity.id}
                className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
              >
                <h3 className="text-2xl font-bold text-paco mb-2">{opportunity.title}</h3>
                <div className="flex flex-wrap gap-4 mb-4">
                  <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">{opportunity.date}</span>
                  <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                    {opportunity.location}
                  </span>
                </div>
                <p className="text-gray-700 mb-6">{opportunity.description}</p>
                <div className="text-center">
                  <Link
                    href={`/opportunities/future/${opportunity.id}`}
                    className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-gold transition-colors inline-block"
                  >
                    Learn More
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-paco mb-6 text-center">Express Interest in Future Opportunities</h3>

            {isSubmitted ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                <h4 className="text-xl font-bold text-green-700 mb-2">Thank You!</h4>
                <p className="text-gray-700">
                  We've received your information and will notify you about future opportunities that match your
                  interests.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl mx-auto">
                <div>
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  />
                </div>

                <div>
                  <label htmlFor="interests" className="block text-gray-700 font-medium mb-2">
                    What types of opportunities are you interested in? *
                  </label>
                  <textarea
                    id="interests"
                    name="interests"
                    value={formData.interests}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-paco"
                  ></textarea>
                </div>

                <div className="text-center">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block disabled:opacity-70"
                  >
                    {isSubmitting ? "Submitting..." : "Submit"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>
    </>
  )
}
