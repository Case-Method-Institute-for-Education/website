import D3CountyMap from "@/components/d3-county-map"

export default function Partners() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Partner Teachers</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 mb-8 max-w-3xl mx-auto italic">
            <p className="text-lg">
              <span className="text-xl">"</span>The Case Method gave my kids confidence and belief in their ability to
              complete academically challenging material. Thank you!<span className="text-xl">"</span>{" "}
              <em className="font-semibold">— CMI partner teacher</em>
            </p>
          </blockquote>

          <div className="max-w-5xl mx-auto mb-12">
            <p className="text-gray-700 mb-8 text-center">
              Become one of our partner teachers. Join the more than 4,000 history, government, and civics teachers from
              across the country who have attended our professional development workshops and learned to teach by the
              case method. Everything – including the PD workshops, cases, teaching materials, and ongoing one-on-one
              support – is made available entirely free of charge.
            </p>

            <h2 className="text-2xl font-bold text-paco mb-6 text-center">Our Partner Teachers Across the U.S.</h2>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
              <div className="lg:col-span-3 bg-card rounded-lg shadow-sm border p-4">
                <D3CountyMap />
              </div>
              <div className="lg:col-span-1">
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <h3 className="text-lg font-semibold text-paco mb-2">Program Highlights</h3>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>4,800+ partner teachers</li>
                      <li>48 states represented</li>
                      <li>1,200+ schools</li>
                      <li>210,000+ students reached</li>
                    </ul>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <h3 className="text-lg font-semibold text-paco mb-2">Top States</h3>
                    <ol className="list-decimal pl-5 space-y-1 text-gray-700">
                      <li>California (612 teachers)</li>
                      <li>New York (487 teachers)</li>
                      <li>Texas (356 teachers)</li>
                      <li>Pennsylvania (312 teachers)</li>
                      <li>Florida (298 teachers)</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center mt-8">
              <a
                href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
              >
                APPLY HERE
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
