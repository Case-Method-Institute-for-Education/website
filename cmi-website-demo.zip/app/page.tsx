"use client"

import HeroSection from "@/components/hero-section"
import Link from "next/link"
import TestimonialCard from "@/components/testimonial-card"
import NewsCard from "@/components/news-card"
import { useState } from "react"
import VideoModal from "@/components/video-modal"
import MapSection from "@/components/map-section"
import FeaturedTestimonial from "@/components/featured-testimonial"

// News items for the homepage
const newsItems = [
  {
    id: 1,
    title: "A Better Way to Teach History",
    date: "8 FEB 2016",
    source: "The Atlantic",
    excerpt:
      "One professor is borrowing a method from Harvard Business School to engage students and inspire better decision-making skills.",
    url: "https://www.theatlantic.com/education/archive/2016/02/harvard-history-class/460314/",
    thumbnail:
      "https://cdn.theatlantic.com/thumbor/Xt9vOLYpYWrLFLEkrqLj-tPjYbs=/0x0:2000x1125/1952x1098/media/img/mt/2016/02/RTR2CKQE/original.jpg",
  },
  {
    id: 2,
    title: "Rewriting History",
    date: "2 MAR 2016",
    source: "HBS Alumni Bulletin",
    excerpt: "Can one HBS professor change how American history is taught in high schools?",
    url: "https://www.alumni.hbs.edu/stories/Pages/story-impact.aspx?num=5151",
    thumbnail: "https://www.alumni.hbs.edu/PublishingImages/impact/education/moss-david-1200x630.jpg",
  },
  {
    id: 3,
    title: "All Hail Partisan Politics",
    date: "9 FEB 2017",
    source: "Harvard Gazette",
    excerpt:
      "David Moss spoke with the Gazette about the book and about a new initiative to bring his case studies into dozens of high school classrooms, where they're used as an interactive teaching tool.",
    url: "https://news.harvard.edu/gazette/story/2017/02/all-hail-partisan-politics/",
    thumbnail: "https://news.harvard.edu/wp-content/uploads/2017/02/moss_david_2016_1500x1000-1200x800.jpg",
  },
  {
    id: 4,
    title: "How to Teach Civics in School",
    date: "6 JUL 2017",
    source: "The Economist",
    excerpt:
      'Inspired by his years using the "case method" developed by Harvard Business School, David Moss has adapted the approach to the study of American democracy.',
    url: "https://www.economist.com/blogs/democracyinamerica/2017/07/civics-lessons",
    thumbnail:
      "https://www.economist.com/sites/default/files/images/2017/07/blogs/democracy-in-america/20170708_usp501.jpg",
  },
]

export default function Home() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  return (
    <>
      <HeroSection />

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-paco mb-6 text-center md:text-left">
                The Case Method Institute for Education & Democracy
              </h2>

              <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 italic">
                <p className="text-lg">
                  <span className="text-xl">"</span>We just finished the Madison case. It took 5 days and it has been
                  the most rewarding experience so far in my 22 year career!<span className="text-xl">"</span> —{" "}
                  <em className="font-semibold">CMI partner teacher in 2024</em>
                </p>
              </blockquote>

              <div className="prose max-w-none text-gray-700">
                <p className="mb-4">
                  Based on the long-standing success of case-method teaching in business and other professional schools,
                  the Case Method Institute has sought to bring case-based teaching to high schools as well. Working
                  with several thousand teachers over recent years, the Institute has convincingly demonstrated that
                  case-based teaching is highly effective in high school education, just as it is in professional
                  education, helping to ensure a more exciting, relevant, and rewarding experience for both students and
                  teachers.
                </p>
                <p>
                  In particular, teaching history, government, and civics by the case method has been shown to
                  strengthen high school students' academic performance, improving critical thinking, argumentation
                  skills, and even mastery of course content. It also contributes to increasing students' civic
                  interest, knowledge, and engagement, presenting a unique opportunity to help reverse the broad decline
                  in civic education in the United States.
                </p>
              </div>
            </div>

            <div className="space-y-8">
              <div className="border-b border-gray-200 pb-6">
                <Link
                  href="/apply"
                  className="text-xl font-semibold text-cherrywood hover:underline block mb-3 text-center md:text-left"
                >
                  For Prospective Partners →
                </Link>
                <p className="text-gray-700">
                  All training, teaching materials, and ongoing support are provided entirely free of charge to
                  participant teachers.
                </p>
              </div>

              <div className="border-b border-gray-200 pb-6">
                <Link
                  href="/curriculum"
                  className="text-xl font-semibold text-cherrywood hover:underline block mb-3 text-center md:text-left"
                >
                  To see the Curriculum →
                </Link>
                <p className="text-gray-700">
                  From the Constitutional Convention to the Civil Rights Movement and beyond, each of our cases explores
                  a key decision point in the history of American democracy.
                </p>
              </div>

              <div>
                <Link
                  href="/partners"
                  className="text-xl font-semibold text-cherrywood hover:underline block mb-3 text-center md:text-left"
                >
                  For Current Partners →
                </Link>
                <p className="text-gray-700">Connect with a teacher support specialist.</p>
                <p className="text-gray-700">
                  Gain access to cases and other teaching materials via{" "}
                  <a
                    href="https://www.sharevault.net/documents?svid=5107"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cherrywood hover:underline"
                  >
                    ShareVault.
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <MapSection />

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-3xl font-bold text-paco mb-12 text-center">Teacher Testimonials</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <TestimonialCard
              name="Eleanor Cannon"
              location="Houston, TX"
              description="Eleanor Cannon describes her students' reactions to the case method."
              videoUrl="https://vimeo.com/1034792891?share=copy"
            />

            <TestimonialCard
              name="Maureen O'Hern"
              location="Dorchester, MA"
              description="Maureen O'Hern describes how the case method transformed her classroom."
              videoUrl="https://vimeo.com/1034794729?share=copy"
            />

            <TestimonialCard
              name="Michael Gordon"
              location="Munster, IN"
              description="Michael Gordon describes why he would recommend the case method to other teachers."
              videoUrl="https://vimeo.com/1034795442?share=copy"
            />
          </div>

          <FeaturedTestimonial
            name="Rhonda Feder"
            location="Teacher, Philadelphia, PA"
            quote="I have had few weeks in teaching that I enjoyed as much as doing this case....My biggest dilemma now is how many cases I want to fit into the year."
            videoUrl="https://vimeo.com/1034793871?share=copy"
          />
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-3xl font-bold text-paco mb-12 text-center">In the News</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {newsItems.map((item) => (
              <NewsCard
                key={item.id}
                title={item.title}
                date={item.date}
                source={item.source}
                excerpt={item.excerpt}
                url={item.url}
                thumbnail={item.thumbnail}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl="https://vimeo.com/1034793871?share=copy"
      />
    </>
  )
}
