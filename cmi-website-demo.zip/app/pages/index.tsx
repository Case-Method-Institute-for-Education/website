"use client"

import Head from "next/head"
import Link from "next/link"
import { Play } from "lucide-react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import HeroSection from "@/components/hero-section"
import TestimonialCard from "@/components/testimonial-card"
import NewsItem from "@/components/news-item"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Head>
        <title>Case Method Institute for Education and Democracy</title>
        <meta
          name="description"
          content="Bringing case method teaching to high schools: U.S. History, Government, Civics & Democracy"
        />
      </Head>

      <Header />

      <main>
        <HeroSection />

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold text-paco mb-6">
                  The Case Method Institute for Education & Democracy
                </h2>

                <blockquote className="border-l-4 border-cherrywood pl-4 italic my-6 text-gray-700">
                  <strong>
                    "We just finished the Madison case. It took 5 days and it has been the most rewarding experience so
                    far in my 22 year career!" — <em>CMI partner teacher in 2024</em>
                  </strong>
                </blockquote>

                <div className="prose max-w-none text-gray-700">
                  <p className="mb-4">
                    Based on the long-standing success of case-method teaching in business and other professional
                    schools, the Case Method Institute has sought to bring case-based teaching to high schools as well.
                    Working with several thousand teachers over recent years, the Institute has convincingly
                    demonstrated that case-based teaching is highly effective in high school education, just as it is in
                    professional education, helping to ensure a more exciting, relevant, and rewarding experience for
                    both students and teachers.
                  </p>
                  <p>
                    In particular, teaching history, government, and civics by the case method has been shown to
                    strengthen high school students' academic performance, improving critical thinking, argumentation
                    skills, and even mastery of course content. It also contributes to increasing students' civic
                    interest, knowledge, and engagement, presenting a unique opportunity to help reverse the broad
                    decline in civic education in the United States.
                  </p>
                </div>
              </div>

              <div className="space-y-8">
                <div className="border-b border-gray-200 pb-6">
                  <Link href="/apply" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                    For Prospective Partners →
                  </Link>
                  <p className="text-gray-700">
                    All training, teaching materials, and ongoing support are provided entirely free of charge to
                    participant teachers.
                  </p>
                </div>

                <div className="border-b border-gray-200 pb-6">
                  <Link href="/curriculum" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                    To see the Curriculum →
                  </Link>
                  <p className="text-gray-700">
                    From the Constitutional Convention to the Civil Rights Movement and beyond, each of our cases
                    explores a key decision point in the history of American democracy.
                  </p>
                </div>

                <div>
                  <Link href="/partners" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                    For Current Partners →
                  </Link>
                  <p className="text-gray-700">Connect with a teacher support specialist.</p>
                  <p className="text-gray-700">
                    Gain access to cases and other teaching materials via{" "}
                    <a
                      href="https://www.sharevault.net/documents?svid=5107"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cherrywood hover:underline"
                    >
                      ShareVault.
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-paco mb-12 text-center">Teacher Testimonials</h2>

            <div className="grid md:grid-cols-3 gap-8">
              <TestimonialCard
                name="Eleanor Cannon"
                location="Houston, TX"
                description="Eleanor Cannon describes her students' reactions to the case method."
                videoUrl="https://vimeo.com/1034792891?share=copy"
              />

              <TestimonialCard
                name="Maureen O'Hern"
                location="Dorchester, MA"
                description="Maureen O'Hern describes how the case method transformed her classroom."
                videoUrl="https://vimeo.com/1034794729?share=copy"
              />

              <TestimonialCard
                name="Michael Gordon"
                location="Munster, IN"
                description="Michael Gordon describes why he would recommend the case method to other teachers."
                videoUrl="https://vimeo.com/1034795442?share=copy"
              />
            </div>

            <div className="mt-16 bg-cherrywood text-white p-8 rounded-lg">
              <div className="md:flex items-center">
                <div className="md:w-2/3 mb-6 md:mb-0 md:pr-8">
                  <h3 className="text-2xl font-bold mb-4">
                    "I have had few weeks in teaching that I enjoyed as much as doing this case....My biggest dilemma
                    now is how many cases I want to fit into the year."
                  </h3>
                  <p className="text-xl font-semibold">Rhonda Feder</p>
                  <p className="text-white/80">Teacher, Philadelphia, PA</p>
                  <button
                    onClick={() => window.open("https://vimeo.com/1034793871?share=copy", "_blank")}
                    className="mt-6 bg-white text-cherrywood px-6 py-3 rounded font-medium hover:bg-gray-100 transition-colors inline-flex items-center"
                  >
                    <Play className="h-5 w-5 mr-2" />
                    WATCH INTRODUCTORY VIDEO
                  </button>
                </div>
                <div className="md:w-1/3 bg-gray-200 h-64 rounded-lg flex items-center justify-center">
                  <span className="sr-only">Featured testimonial image</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-paco mb-12 text-center">In the News</h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <NewsItem
                title="A Better Way to Teach History"
                date="8 FEB 2016"
                source="The Atlantic"
                excerpt="One professor is borrowing a method from Harvard Business School to engage students and inspire better decision-making skills."
                url="https://www.theatlantic.com/education/archive/2016/02/harvard-history-class/460314/"
              />

              <NewsItem
                title="Rewriting History"
                date="2 MAR 2016"
                source="HBS Alumni Bulletin"
                excerpt="Can one HBS professor change how American history is taught in high schools?"
                url="https://www.alumni.hbs.edu/stories/Pages/story-impact.aspx?num=5151"
              />

              <NewsItem
                title="All Hail Partisan Politics"
                date="9 FEB 2017"
                source="Harvard Gazette"
                excerpt="David Moss spoke with the Gazette about the book and about a new initiative to bring his case studies into dozens of high school classrooms, where they're used as an interactive teaching tool."
                url="https://news.harvard.edu/gazette/story/2017/02/all-hail-partisan-politics/"
              />

              <NewsItem
                title="How to Teach Civics in School"
                date="6 JUL 2017"
                source="The Economist"
                excerpt="Inspired by his years using the &quot;case method&quot; developed by Harvard Business School, David Moss has adapted the approach to the study of American democracy."
                url="https://www.economist.com/blogs/democracyinamerica/2017/07/civics-lessons"
              />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
