import Link from "next/link"

type JobPosting = {
  id: number
  title: string
  location: string
  type: string
  description: string
}

const jobPostings: JobPosting[] = [
  {
    id: 1,
    title: "Teacher Support Specialist",
    location: "Cambridge, MA",
    type: "Full-time",
    description:
      "Work directly with our partner teachers to provide support and guidance in implementing case method teaching in their classrooms.",
  },
  {
    id: 2,
    title: "Curriculum Developer",
    location: "Remote",
    type: "Full-time",
    description:
      "Help develop new case studies and supporting materials for high school history, government, and civics classrooms.",
  },
  {
    id: 3,
    title: "Professional Development Coordinator",
    location: "Cambridge, MA",
    type: "Full-time",
    description: "Organize and facilitate professional development workshops for teachers across the country.",
  },
]

export default function Careers() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Careers</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-paco mb-6">Join Our Team</h2>
            <p className="text-gray-700 mb-6">
              The Case Method Institute is dedicated to strengthening student engagement and learning in high school
              history, government, and civics classrooms through case method teaching. We're looking for passionate
              individuals to join our team and help us expand our impact.
            </p>
          </div>

          <div className="space-y-8">
            {jobPostings.map((job) => (
              <div key={job.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="text-2xl font-bold text-paco mb-2">{job.title}</h3>
                <div className="flex flex-wrap gap-4 mb-4">
                  <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">{job.location}</span>
                  <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">{job.type}</span>
                </div>
                <p className="text-gray-700 mb-6">{job.description}</p>
                <Link
                  href={`/careers/${job.id}`}
                  className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-gold transition-colors inline-block"
                >
                  View Details
                </Link>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-gray-50 p-8 rounded-lg text-center">
            <h3 className="text-2xl font-bold text-paco mb-4">Don't see a position that fits?</h3>
            <p className="text-gray-700 mb-6">
              We're always looking for talented individuals who are passionate about education and democracy. Send us
              your resume and a cover letter explaining why you'd like to join our team.
            </p>
            <a
              href="mailto:careers@cmi.org"
              className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-gold transition-colors inline-block"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </>
  )
}
