import Link from "next/link"
import D3CountyMap from "@/components/d3-county-map"

export default function PartnersPage() {
  return (
    <main className="min-h-screen bg-white p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold text-cherrywood">CMI Partner Teachers Network</h1>
          <p className="text-gray-600">Explore the distribution of CMI partner teachers across the United States</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6 overflow-visible">
          <D3CountyMap />
        </div>

        <div className="text-center my-8">
          <a
            href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gold text-white px-6 py-3 rounded font-medium hover:bg-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 inline-block"
          >
            APPLY TO BECOME A PARTNER TEACHER
          </a>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-bold text-paco mb-6">Join Our Growing Network</h2>
            <p className="text-gray-700 mb-4">
              The Case Method Institute has partnered with thousands of teachers across the United States, bringing
              case-based teaching to high schools in 48 states and the District of Columbia. Our partner teachers
              receive comprehensive training, teaching materials, and ongoing support entirely free of charge.
            </p>

            <h3 className="text-xl font-semibold text-cherrywood mt-6 mb-3">Benefits of Becoming a Partner Teacher</h3>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li>Access to our complete curriculum of case studies</li>
              <li>Professional development workshops and training</li>
              <li>Ongoing support from teacher specialists</li>
              <li>Connection to a nationwide community of educators</li>
              <li>Resources to enhance student engagement and critical thinking</li>
            </ul>
          </div>

          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-6">
              <Link href="/apply" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                For Prospective Partners →
              </Link>
              <p className="text-gray-700">
                All training, teaching materials, and ongoing support are provided entirely free of charge to
                participant teachers.
              </p>
            </div>

            <div className="border-b border-gray-200 pb-6">
              <Link href="/curriculum" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                To see the Curriculum →
              </Link>
              <p className="text-gray-700">
                From the Constitutional Convention to the Civil Rights Movement and beyond, each of our cases explores a
                key decision point in the history of American democracy.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-cherrywood mb-3">For Current Partners</h3>
              <p className="text-gray-700">Connect with a teacher support specialist.</p>
              <p className="text-gray-700">
                Gain access to cases and other teaching materials via{" "}
                <a
                  href="https://www.sharevault.net/documents?svid=5107"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-cherrywood hover:underline"
                >
                  ShareVault.
                </a>
              </p>
            </div>
          </div>
        </div>

        <blockquote className="border-l-4 border-cherrywood pl-4 my-6 text-gray-700 italic bg-gray-50 p-6 rounded-lg">
          <p className="text-lg">
            <span className="text-xl">"</span>We just finished the Madison case. It took 5 days and it has been the most
            rewarding experience so far in my 22 year career!<span className="text-xl">"</span> —{" "}
            <em className="font-semibold">CMI partner teacher in 2024</em>
          </p>
        </blockquote>

        <div className="text-sm text-gray-500">
          <p>Data last updated: March 2025</p>
          <p>Source: CMI Partner Teacher Database</p>
        </div>
      </div>
    </main>
  )
}
