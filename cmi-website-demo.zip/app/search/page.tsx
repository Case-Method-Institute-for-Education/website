import Link from "next/link"
import { Search } from "lucide-react"

export default function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const query = searchParams.q || ""

  // This is a placeholder search results page
  // In a real implementation, you would integrate with your search system

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-paco mb-6">Search Results</h1>

        <div className="relative mb-8">
          <form action="/search" method="get" className="flex">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                name="q"
                defaultValue={query}
                placeholder="Search..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-paco focus:border-transparent"
              />
            </div>
            <button
              type="submit"
              className="bg-gold hover:bg-cherrywood hover:text-white text-navy px-6 py-2 rounded-r-md font-medium transition-colors"
            >
              Search
            </button>
          </form>
        </div>

        {query ? (
          <>
            <p className="text-gray-600 mb-6">
              Showing results for: <span className="font-semibold">{query}</span>
            </p>

            <div className="space-y-6">
              {/* Sample search results - in a real implementation, these would be dynamic */}
              <div className="border-b border-gray-200 pb-4">
                <Link href="/curriculum" className="text-xl font-semibold text-cherrywood hover:underline">
                  Curriculum Overview
                </Link>
                <p className="text-gray-600 mt-1">
                  From the Constitutional Convention to the Civil Rights Movement and beyond, each of our cases explores
                  a key decision point in the history of American democracy.
                </p>
              </div>

              <div className="border-b border-gray-200 pb-4">
                <Link
                  href="/about/case-method-teaching"
                  className="text-xl font-semibold text-cherrywood hover:underline"
                >
                  Case Method Teaching
                </Link>
                <p className="text-gray-600 mt-1">
                  Learn about the case method approach and how it can transform your classroom experience.
                </p>
              </div>

              <div className="border-b border-gray-200 pb-4">
                <Link href="/partners" className="text-xl font-semibold text-cherrywood hover:underline">
                  Partner Teachers Network
                </Link>
                <p className="text-gray-600 mt-1">
                  Join our growing network of teachers across the United States who are implementing case method
                  teaching in their classrooms.
                </p>
              </div>
            </div>

            <p className="text-gray-500 mt-8 text-sm">
              Note: This is a placeholder search results page. In a production environment, this would be connected to a
              real search system.
            </p>
          </>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600">Please enter a search term to see results.</p>
          </div>
        )}
      </div>
    </div>
  )
}
