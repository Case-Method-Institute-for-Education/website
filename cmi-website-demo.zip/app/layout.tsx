import type React from "react"
import type { Metadata } from "next"
import { Work_Sans } from "next/font/google"
import localFont from "next/font/local"
import "./globals.css"
import ModernHeader from "@/components/modern-header"
import Footer from "@/components/footer"
// Import the ScrollToTop component
import ScrollToTop from "@/components/scroll-to-top"

const workSans = Work_Sans({
  subsets: ["latin"],
  variable: "--font-work-sans",
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
})

// Add Schola Serif font
const scholaSerif = localFont({
  src: [
    {
      path: "../public/fonts/ScholaSerif-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "../public/fonts/ScholaSerif-Bold.woff2",
      weight: "700",
      style: "normal",
    },
  ],
  variable: "--font-schola-serif",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Case Method Institute for Education and Democracy",
  description: "Bringing case method teaching to high schools: U.S. History, Government, Civics & Democracy",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${workSans.variable} ${scholaSerif.variable}`}>
      {/* Add the ScrollToTop component inside the body element, right after the opening tag */}
      <body className="min-h-screen bg-white font-worksans">
        <ScrollToTop />
        <div className="flex flex-col min-h-screen">
          <ModernHeader />
          <main className="flex-grow">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  )
}
