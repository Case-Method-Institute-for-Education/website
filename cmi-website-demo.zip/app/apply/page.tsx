export default function Apply() {
  return (
    <>
      <section className="py-16 bg-paco text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Apply</h1>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-paco mb-6">Become a Partner Teacher</h2>
            <p className="text-gray-700 mb-6">
              The Case Method Institute invites high school teachers of U.S. history, government, and civics to apply to
              our professional development program. All training, teaching materials, and ongoing support are provided
              entirely free of charge to participant teachers.
            </p>
          </div>

          <div className="bg-gray-50 p-8 rounded-lg mb-12">
            <h3 className="text-2xl font-bold text-paco mb-4 text-center">Program Benefits</h3>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6 max-w-lg mx-auto">
              <li>Free professional development workshops led by experienced educators</li>
              <li>Complete set of case materials for classroom use</li>
              <li>Ongoing support from our teacher support specialists</li>
              <li>Access to a community of like-minded educators</li>
              <li>Opportunity to transform your classroom into a dynamic learning environment</li>
            </ul>
          </div>

          <div className="mb-12">
            <h3 className="text-2xl font-bold text-paco mb-4 text-center">Eligibility</h3>
            <p className="text-gray-700 mb-6 text-center">We welcome applications from teachers who:</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6 max-w-lg mx-auto">
              <li>Teach U.S. history, government, or civics at the high school level</li>
              <li>Are committed to implementing case method teaching in their classrooms</li>
              <li>Are interested in strengthening students' critical thinking and civic engagement</li>
            </ul>
          </div>

          <div className="text-center">
            <a
              href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-navy text-white px-6 py-3 rounded font-medium hover:bg-gold transition-colors inline-block"
            >
              APPLY NOW
            </a>
          </div>
        </div>
      </section>
    </>
  )
}
