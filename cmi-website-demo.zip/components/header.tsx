"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Search, Play } from "lucide-react"
import VideoModal from "./video-modal"

export default function Header() {
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false)
  const [isOpportunitiesDropdownOpen, setIsOpportunitiesDropdownOpen] = useState(false)
  const [aboutDropdownTimeout, setAboutDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [opportunitiesDropdownTimeout, setOpportunitiesDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      // For header transparency effect
      if (window.scrollY > 20) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      // Clear any pending timeouts when component unmounts
      if (aboutDropdownTimeout) clearTimeout(aboutDropdownTimeout)
      if (opportunitiesDropdownTimeout) clearTimeout(opportunitiesDropdownTimeout)
    }
  }, [aboutDropdownTimeout, opportunitiesDropdownTimeout])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  const isActive = (path: string) => {
    if (path === "/") {
      return pathname === path
    }
    return pathname.startsWith(path)
  }

  const handleAboutMouseLeave = () => {
    const timeout = setTimeout(() => {
      setIsAboutDropdownOpen(false)
    }, 100) // 100ms delay before closing
    setAboutDropdownTimeout(timeout)
  }

  const handleOpportunitiesMouseLeave = () => {
    const timeout = setTimeout(() => {
      setIsOpportunitiesDropdownOpen(false)
    }, 100) // 100ms delay before closing
    setOpportunitiesDropdownTimeout(timeout)
  }

  return (
    <>
      <header
        className={`text-white transition-all duration-300 ${
          isScrolled ? "bg-paco/95 backdrop-blur-sm shadow-md" : "bg-paco"
        }`}
      >
        <div className="container mx-auto px-4">
          {/* Top section with logo and buttons */}
          <div className="flex justify-between items-center py-3">
            <Link href="/" className="flex items-center">
              {/* Logo placeholder - replace with your actual logo */}
              <div className="h-12 w-40 relative flex items-center">
                {/* This is a placeholder that you can remove once you add your logo */}
                <div className="border-2 border-dashed border-white/50 w-full h-full flex items-center justify-center">
                  <span className="text-white/70 text-sm">Add your logo here</span>
                </div>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-white/10 text-white placeholder-white/60 px-3 py-1.5 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/30 w-40 transition-all duration-300 focus:w-52"
                />
                <Search className="absolute right-2 top-1.5 h-4 w-4 text-white/60" />
              </div>
              <button
                onClick={openVideoModal}
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-sm shadow-sm hover:shadow-md flex items-center"
              >
                <Play size={16} className="mr-1" />
                INTRODUCTORY VIDEO
              </button>
              <a
                href="https://www.sharevault.net/documents?svid=5107"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-sm shadow-sm hover:shadow-md"
              >
                SHAREVAULT
              </a>
            </div>

            <button className="md:hidden text-white" onClick={toggleMenu} aria-label="Toggle menu">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Thin white border separator */}
          <div className="border-t border-white/30"></div>

          {/* Navigation section */}
          <nav className={`${isMenuOpen ? "block" : "hidden"} md:block py-2`}>
            <ul className="flex flex-col md:flex-row md:justify-center md:space-x-4 space-y-3 md:space-y-0 items-center">
              <li>
                <Link
                  href="/"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  HOME
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/about"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/about")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={() => {
                    if (aboutDropdownTimeout) {
                      clearTimeout(aboutDropdownTimeout)
                      setAboutDropdownTimeout(null)
                    }
                    setIsAboutDropdownOpen(true)
                  }}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  ABOUT US
                </Link>

                {/* About Dropdown menu */}
                <div
                  className={`absolute left-0 w-64 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                    isAboutDropdownOpen
                      ? "opacity-100 translate-y-1 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none"
                  }`}
                  onMouseEnter={() => {
                    if (aboutDropdownTimeout) {
                      clearTimeout(aboutDropdownTimeout)
                      setAboutDropdownTimeout(null)
                    }
                    setIsAboutDropdownOpen(true)
                  }}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  <div className="absolute -top-2 left-4 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/about"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    About Overview
                  </Link>
                  <Link
                    href="/about/case-method-teaching"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/case-method-teaching" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Case Method Teaching
                  </Link>
                  <Link
                    href="/about/professional-development"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/professional-development" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Professional Development
                  </Link>
                  <Link
                    href="/about/team"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/team" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    The Team
                  </Link>
                  <Link
                    href="/about/students"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/students" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Students
                  </Link>
                  <Link
                    href="/about/careers"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/careers" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Careers
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/curriculum"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/curriculum")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  CURRICULUM
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/opportunities"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/opportunities")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={() => {
                    if (opportunitiesDropdownTimeout) {
                      clearTimeout(opportunitiesDropdownTimeout)
                      setOpportunitiesDropdownTimeout(null)
                    }
                    setIsOpportunitiesDropdownOpen(true)
                  }}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  OPPORTUNITIES FOR TEACHERS
                </Link>

                {/* Opportunities Dropdown menu */}
                <div
                  className={`absolute left-0 w-64 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                    isOpportunitiesDropdownOpen
                      ? "opacity-100 translate-y-1 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none"
                  }`}
                  onMouseEnter={() => {
                    if (opportunitiesDropdownTimeout) {
                      clearTimeout(opportunitiesDropdownTimeout)
                      setOpportunitiesDropdownTimeout(null)
                    }
                    setIsOpportunitiesDropdownOpen(true)
                  }}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  <div className="absolute -top-2 left-4 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/partners"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/partners" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Partners
                  </Link>
                  <a
                    href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block px-4 py-2 hover:bg-gray-100 hover:text-paco"
                  >
                    Apply Now
                  </a>
                  <Link
                    href="/opportunities/mailing-list"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/opportunities/mailing-list" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Join Mailing List
                  </Link>
                  <Link
                    href="/opportunities/future"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/opportunities/future" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Future Opportunities
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/press-videos"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/press-videos")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  PRESS & VIDEOS
                </Link>
              </li>
            </ul>
          </nav>

          <div className={`${isMenuOpen ? "flex" : "hidden"} md:hidden flex-col space-y-3 py-3 items-center`}>
            <div className="relative w-full mb-2">
              <input
                type="text"
                placeholder="Search..."
                className="bg-white/10 text-white placeholder-white/60 px-3 py-1.5 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/30 w-full"
              />
              <Search className="absolute right-2 top-1.5 h-4 w-4 text-white/60" />
            </div>
            <button
              onClick={openVideoModal}
              className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full shadow-sm flex items-center justify-center"
            >
              <Play size={16} className="mr-1" />
              INTRODUCTORY VIDEO
            </button>
            <a
              href="https://www.sharevault.net/documents?svid=5107"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full text-center shadow-sm"
            >
              SHAREVAULT
            </a>
          </div>
        </div>
      </header>

      {/* Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl="https://vimeo.com/1034793871?share=copy"
      />
    </>
  )
}
