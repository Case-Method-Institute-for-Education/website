"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { ChevronRight, Home } from "lucide-react"

export default function Breadcrumbs() {
  const pathname = usePathname()

  // Don't show breadcrumbs on homepage
  if (pathname === "/") return null

  // Don't show on navigation demo page (it has its own)
  if (pathname === "/navigation-demo") return null

  // Don't show on the private audio page
  if (pathname.includes("cmi-partner-audio-library")) return null

  // Create breadcrumb segments
  const segments = pathname.split("/").filter(Boolean)

  // Generate breadcrumb paths and format the names
  const breadcrumbs = segments.map((segment, index) => {
    const path = `/${segments.slice(0, index + 1).join("/")}`

    // Format the segment name for display
    let name = segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ")

    // Special case handling for common abbreviations and terms
    if (name === "About") name = "About Us"
    if (name === "Press videos") name = "Press & Videos"

    return {
      name,
      path,
    }
  })

  return (
    <div className="breadcrumb-bar py-2 px-4">
      <div className="container mx-auto">
        <ol className="flex flex-wrap items-center text-xs md:text-sm text-gray-600">
          <li className="flex items-center">
            <Link href="/" className="text-paco hover:text-cherrywood transition-colors flex items-center">
              <Home size={12} className="mr-1" />
              <span>Home</span>
            </Link>
          </li>

          {breadcrumbs.map((breadcrumb, index) => (
            <li key={breadcrumb.path} className="flex items-center">
              <ChevronRight size={12} className="mx-1 text-gray-400" />
              {index === breadcrumbs.length - 1 ? (
                <span className="font-medium text-gray-800">{breadcrumb.name}</span>
              ) : (
                <Link href={breadcrumb.path} className="text-paco hover:text-cherrywood transition-colors">
                  {breadcrumb.name}
                </Link>
              )}
            </li>
          ))}
        </ol>
      </div>
    </div>
  )
}
