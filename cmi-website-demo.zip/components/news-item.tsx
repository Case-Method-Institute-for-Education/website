interface NewsItemProps {
  title: string
  date: string
  source: string
  excerpt: string
  url: string
}

export default function NewsItem({ title, date, source, excerpt, url }: NewsItemProps) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
      <div className="bg-gray-200 h-48"></div>
      <div className="p-6">
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xl font-bold text-paco hover:text-cherrywood transition-colors block mb-2"
        >
          {title}
        </a>
        <p className="text-sm text-gray-500 mb-4">
          {date} | {source}
        </p>
        <p className="text-gray-700">{excerpt}</p>
      </div>
    </div>
  )
}
