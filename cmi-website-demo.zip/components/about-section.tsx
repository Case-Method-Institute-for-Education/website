import Link from "next/link"

export default function AboutSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl font-bold text-paco mb-6">The Case Method Institute for Education & Democracy</h2>

            <blockquote className="border-l-4 border-cherrywood pl-4 italic my-6 text-gray-700">
              <strong>
                "We just finished the Madison case. It took 5 days and it has been the most rewarding experience so far
                in my 22 year career!" — <em>CMI partner teacher in 2024</em>
              </strong>
            </blockquote>

            <div className="prose max-w-none text-gray-700">
              <p className="mb-4">
                Based on the long-standing success of case-method teaching in business and other professional schools,
                the Case Method Institute has sought to bring case-based teaching to high schools as well. Working with
                several thousand teachers over recent years, the Institute has convincingly demonstrated that case-based
                teaching is highly effective in high school education, just as it is in professional education, helping
                to ensure a more exciting, relevant, and rewarding experience for both students and teachers.
              </p>
              <p>
                In particular, teaching history, government, and civics by the case method has been shown to strengthen
                high school students' academic performance, improving critical thinking, argumentation skills, and even
                mastery of course content. It also contributes to increasing students' civic interest, knowledge, and
                engagement, presenting a unique opportunity to help reverse the broad decline in civic education in the
                United States.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <div className="border-b border-gray-200 pb-6">
              <Link href="/apply" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                For Prospective Partners →
              </Link>
              <p className="text-gray-700">
                All training, teaching materials, and ongoing support are provided entirely free of charge to
                participant teachers.
              </p>
            </div>

            <div className="border-b border-gray-200 pb-6">
              <Link href="/curriculum" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                To see the Curriculum →
              </Link>
              <p className="text-gray-700">
                From the Constitutional Convention to the Civil Rights Movement and beyond, each of our cases explores a
                key decision point in the history of American democracy.
              </p>
            </div>

            <div>
              <Link href="/partners" className="text-xl font-semibold text-cherrywood hover:underline block mb-3">
                For Current Partners →
              </Link>
              <p className="text-gray-700">Connect with a teacher support specialist.</p>
              <p className="text-gray-700">
                Gain access to cases and other teaching materials via{" "}
                <a
                  href="https://www.sharevault.net/documents?svid=5107"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-cherrywood hover:underline"
                >
                  ShareVault.
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
