import * as React from "react"
import { ArrowRightIcon } from "lucide-react"

export const ArrowRight = React.forwardRef<
  SVGSVGElement & { title?: string | undefined },
  React.SVGAttributes<SVGSVGElement>
>(({ className, ...props }, ref) => {
  return <ArrowRightIcon ref={ref} className={className} {...props} />
})
ArrowRight.displayName = "ArrowRight"
