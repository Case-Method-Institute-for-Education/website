import Link from "next/link"

export default function HeroSection() {
  return (
    <section className="py-24 md:py-32 text-white bg-paco relative">
      {/* This div will be where you can place a background image */}
      <div className="absolute inset-0 bg-cover bg-center z-0">
        {/* You can add an image here with: style={{ backgroundImage: "url('/your-image.jpg')" }} */}
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="bg-navy/90 backdrop-blur-sm p-6 md:p-8 rounded-lg max-w-3xl mx-auto border-l-4 border-gold">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-normal mb-8 leading-tight">
            Bringing case method teaching to U.S. high schools in History, Government, & Civics
          </h1>
          <div className="flex flex-col md:flex-row justify-center gap-4 mt-8">
            <Link
              href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gold text-white px-6 py-3 rounded font-medium hover:bg-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 shadow-md"
            >
              APPLY NOW
            </Link>
            <Link
              href="/curriculum"
              className="bg-navy border-2 border-gold text-white px-6 py-3 rounded font-medium hover:bg-cherrywood hover:border-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 shadow-md"
            >
              VIEW CURRICULUM
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
