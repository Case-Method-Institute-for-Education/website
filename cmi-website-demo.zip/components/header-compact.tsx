"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Search, Play } from "lucide-react"
import VideoModal from "./video-modal"

export default function HeaderCompact() {
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false)
  const [isOpportunitiesDropdownOpen, setIsOpportunitiesDropdownOpen] = useState(false)
  const [aboutDropdownTimeout, setAboutDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [opportunitiesDropdownTimeout, setOpportunitiesDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      // For header transparency effect
      if (window.scrollY > 20) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  const handleAboutMouseEnter = () => {
    if (aboutDropdownTimeout) {
      clearTimeout(aboutDropdownTimeout)
      setAboutDropdownTimeout(null)
    }
    setIsAboutDropdownOpen(true)
  }

  const handleAboutMouseLeave = () => {
    setAboutDropdownTimeout(
      setTimeout(() => {
        setIsAboutDropdownOpen(false)
      }, 50),
    )
  }

  const handleOpportunitiesMouseEnter = () => {
    if (opportunitiesDropdownTimeout) {
      clearTimeout(opportunitiesDropdownTimeout)
      setOpportunitiesDropdownTimeout(null)
    }
    setIsOpportunitiesDropdownOpen(true)
  }

  const handleOpportunitiesMouseLeave = () => {
    setOpportunitiesDropdownTimeout(
      setTimeout(() => {
        setIsOpportunitiesDropdownOpen(false)
      }, 50),
    )
  }

  // Check if a link is active
  const isActive = (path: string) => {
    if (path === "/") {
      return pathname === path
    }
    return pathname.startsWith(path)
  }

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 text-white transition-all duration-300 ${
          isScrolled ? "bg-paco/95 backdrop-blur-sm shadow-md" : "bg-paco"
        }`}
      >
        <div className="container mx-auto px-4">
          {/* Compact header with integrated navigation */}
          <div className="flex justify-between items-center py-2.5">
            <Link href="/" className="flex items-center">
              {/* Smaller logo */}
              <div className="h-10 w-32 relative flex items-center">
                <div className="border-2 border-dashed border-white/50 w-full h-full flex items-center justify-center">
                  <span className="text-white/70 text-xs">Add your logo here</span>
                </div>
              </div>
            </Link>

            {/* Compact navigation for desktop */}
            <nav className="hidden md:block">
              <ul className="flex items-center space-x-1">
                <li>
                  <Link
                    href="/"
                    className={`text-white font-medium px-3 py-1.5 rounded-md text-xs ${
                      isActive("/")
                        ? "bg-navy/60 shadow-inner"
                        : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                    } transition-all duration-200 inline-block`}
                  >
                    HOME
                  </Link>
                </li>
                <li className="relative group">
                  <Link
                    href="/about"
                    className={`text-white font-medium px-3 py-1.5 rounded-md text-xs ${
                      isActive("/about")
                        ? "bg-navy/60 shadow-inner"
                        : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                    } transition-all duration-200 inline-block`}
                    onMouseEnter={handleAboutMouseEnter}
                    onMouseLeave={handleAboutMouseLeave}
                  >
                    ABOUT US
                  </Link>

                  {/* About Dropdown menu */}
                  <div
                    className={`absolute left-0 w-56 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                      isAboutDropdownOpen
                        ? "opacity-100 translate-y-1 pointer-events-auto"
                        : "opacity-0 -translate-y-1 pointer-events-none"
                    }`}
                    onMouseEnter={handleAboutMouseEnter}
                    onMouseLeave={handleAboutMouseLeave}
                  >
                    <div className="absolute -top-2 left-4 w-3 h-3 bg-white transform rotate-45"></div>
                    <Link
                      href="/about"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      About Overview
                    </Link>
                    <Link
                      href="/about/case-method-teaching"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about/case-method-teaching" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Case Method Teaching
                    </Link>
                    <Link
                      href="/about/professional-development"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about/professional-development" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Professional Development
                    </Link>
                    <Link
                      href="/about/team"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about/team" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      The Team
                    </Link>
                    <Link
                      href="/about/students"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about/students" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Students
                    </Link>
                    <Link
                      href="/about/careers"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/about/careers" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Careers
                    </Link>
                  </div>
                </li>
                <li>
                  <Link
                    href="/curriculum"
                    className={`text-white font-medium px-3 py-1.5 rounded-md text-xs ${
                      isActive("/curriculum")
                        ? "bg-navy/60 shadow-inner"
                        : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                    } transition-all duration-200 inline-block`}
                  >
                    CURRICULUM
                  </Link>
                </li>
                <li className="relative group">
                  <Link
                    href="/opportunities"
                    className={`text-white font-medium px-3 py-1.5 rounded-md text-xs ${
                      isActive("/opportunities")
                        ? "bg-navy/60 shadow-inner"
                        : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                    } transition-all duration-200 inline-block`}
                    onMouseEnter={handleOpportunitiesMouseEnter}
                    onMouseLeave={handleOpportunitiesMouseLeave}
                  >
                    OPPORTUNITIES
                  </Link>

                  {/* Opportunities Dropdown menu */}
                  <div
                    className={`absolute left-0 w-56 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                      isOpportunitiesDropdownOpen
                        ? "opacity-100 translate-y-1 pointer-events-auto"
                        : "opacity-0 -translate-y-1 pointer-events-none"
                    }`}
                    onMouseEnter={handleOpportunitiesMouseEnter}
                    onMouseLeave={handleOpportunitiesMouseLeave}
                  >
                    <div className="absolute -top-2 left-4 w-3 h-3 bg-white transform rotate-45"></div>
                    <Link
                      href="/partners"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/partners" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Partners
                    </Link>
                    <a
                      href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs"
                    >
                      Apply Now
                    </a>
                    <Link
                      href="/opportunities/mailing-list"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/opportunities/mailing-list" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Join Mailing List
                    </Link>
                    <Link
                      href="/opportunities/future"
                      className={`block px-3 py-1.5 hover:bg-gray-100 hover:text-paco text-xs ${
                        pathname === "/opportunities/future" ? "bg-gray-100 text-paco" : ""
                      }`}
                    >
                      Future Opportunities
                    </Link>
                  </div>
                </li>
                <li>
                  <Link
                    href="/press-videos"
                    className={`text-white font-medium px-3 py-1.5 rounded-md text-xs ${
                      isActive("/press-videos")
                        ? "bg-navy/60 shadow-inner"
                        : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                    } transition-all duration-200 inline-block`}
                  >
                    PRESS & VIDEOS
                  </Link>
                </li>
              </ul>
            </nav>

            <div className="hidden md:flex items-center space-x-2">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-white/10 text-white placeholder-white/60 px-2 py-1 rounded text-xs focus:outline-none focus:ring-1 focus:ring-white/30 w-28 transition-all duration-300 focus:w-40"
                />
                <Search className="absolute right-2 top-1 h-3.5 w-3.5 text-white/60" />
              </div>
              <button
                onClick={openVideoModal}
                className="bg-navy text-white px-2 py-1 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-xs shadow-sm hover:shadow-md flex items-center"
              >
                <Play size={12} className="mr-1" />
                VIDEO
              </button>
              <a
                href="https://www.sharevault.net/documents?svid=5107"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-2 py-1 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-xs shadow-sm hover:shadow-md"
              >
                SHAREVAULT
              </a>
            </div>

            <button className="md:hidden text-white" onClick={toggleMenu} aria-label="Toggle menu">
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

          {/* Mobile menu */}
          <div className={`${isMenuOpen ? "block" : "hidden"} md:hidden py-2 border-t border-white/30 mt-1`}>
            <ul className="flex flex-col space-y-2 items-center">
              <li className="w-full">
                <Link
                  href="/"
                  className={`text-white font-medium px-3 py-1.5 rounded-md text-sm ${
                    isActive("/")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 block text-center`}
                >
                  HOME
                </Link>
              </li>
              <li className="w-full">
                <Link
                  href="/about"
                  className={`text-white font-medium px-3 py-1.5 rounded-md text-sm ${
                    isActive("/about")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 block text-center`}
                >
                  ABOUT US
                </Link>
              </li>
              <li className="w-full">
                <Link
                  href="/curriculum"
                  className={`text-white font-medium px-3 py-1.5 rounded-md text-sm ${
                    isActive("/curriculum")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 block text-center`}
                >
                  CURRICULUM
                </Link>
              </li>
              <li className="w-full">
                <Link
                  href="/opportunities"
                  className={`text-white font-medium px-3 py-1.5 rounded-md text-sm ${
                    isActive("/opportunities")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 block text-center`}
                >
                  OPPORTUNITIES
                </Link>
              </li>
              <li className="w-full">
                <Link
                  href="/press-videos"
                  className={`text-white font-medium px-3 py-1.5 rounded-md text-sm ${
                    isActive("/press-videos")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 block text-center`}
                >
                  PRESS & VIDEOS
                </Link>
              </li>
            </ul>

            <div className="flex flex-col space-y-2 py-3 items-center mt-2">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-white/10 text-white placeholder-white/60 px-3 py-1.5 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/30 w-full"
                />
                <Search className="absolute right-2 top-1.5 h-4 w-4 text-white/60" />
              </div>
              <button
                onClick={openVideoModal}
                className="bg-navy text-white px-3 py-1.5 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full shadow-sm flex items-center justify-center"
              >
                <Play size={14} className="mr-1" />
                INTRODUCTORY VIDEO
              </button>
              <a
                href="https://www.sharevault.net/documents?svid=5107"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-3 py-1.5 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full text-center shadow-sm"
              >
                SHAREVAULT
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl="https://vimeo.com/1034793871?share=copy"
      />
    </>
  )
}
