"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Search, Play, ChevronRight, Home } from "lucide-react"
import VideoModal from "./video-modal"

export default function ModernHeader() {
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false)
  const [isOpportunitiesDropdownOpen, setIsOpportunitiesDropdownOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  // Use refs instead of state for timeouts to avoid re-renders
  const aboutTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const opportunitiesTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Refs for dropdown elements
  const aboutDropdownRef = useRef<HTMLDivElement>(null)
  const opportunitiesDropdownRef = useRef<HTMLDivElement>(null)

  // Don't show breadcrumbs on homepage
  const showBreadcrumbs =
    pathname !== "/" && !pathname.includes("navigation-demo") && !pathname.includes("cmi-partner-audio-library")

  // Create breadcrumb segments
  const segments = pathname.split("/").filter(Boolean)

  // Generate breadcrumb paths and format the names
  const breadcrumbs = segments.map((segment, index) => {
    const path = `/${segments.slice(0, index + 1).join("/")}`

    // Format the segment name for display
    let name = segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ")

    // Special case handling for common abbreviations and terms
    if (name === "About") name = "About Us"
    if (name === "Press videos") name = "Press & Videos"

    return {
      name,
      path,
    }
  })

  // Memoized scroll handler to improve performance
  const handleScroll = useCallback(() => {
    if (window.scrollY > 20) {
      if (!isScrolled) setIsScrolled(true)
    } else {
      if (isScrolled) setIsScrolled(false)
    }
  }, [isScrolled])

  // Handle scroll events
  useEffect(() => {
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => {
      window.removeEventListener("scroll", handleScroll)
      // Clear any pending timeouts when component unmounts
      if (aboutTimeoutRef.current) clearTimeout(aboutTimeoutRef.current)
      if (opportunitiesTimeoutRef.current) clearTimeout(opportunitiesTimeoutRef.current)
    }
  }, [handleScroll])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  const handleHeaderSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const searchInput = document.querySelector('input[placeholder="Search..."]') as HTMLInputElement
    const searchValue = searchInput?.value
    if (!searchValue) return
    window.location.href = `/search?q=${encodeURIComponent(searchValue)}`
  }

  // Optimized dropdown handlers
  const handleAboutMouseEnter = useCallback(() => {
    if (aboutTimeoutRef.current) {
      clearTimeout(aboutTimeoutRef.current)
      aboutTimeoutRef.current = null
    }
    setIsAboutDropdownOpen(true)
  }, [])

  const handleAboutMouseLeave = useCallback(() => {
    aboutTimeoutRef.current = setTimeout(() => {
      setIsAboutDropdownOpen(false)
    }, 150)
  }, [])

  const handleOpportunitiesMouseEnter = useCallback(() => {
    if (opportunitiesTimeoutRef.current) {
      clearTimeout(opportunitiesTimeoutRef.current)
      opportunitiesTimeoutRef.current = null
    }
    setIsOpportunitiesDropdownOpen(true)
  }, [])

  const handleOpportunitiesMouseLeave = useCallback(() => {
    opportunitiesTimeoutRef.current = setTimeout(() => {
      setIsOpportunitiesDropdownOpen(false)
    }, 150)
  }, [])

  // Function to check if a link is active
  const isActive = useCallback(
    (href: string): boolean => {
      return pathname === href
    },
    [pathname],
  )

  return (
    <div className="sticky top-0 z-50">
      <header
        className={`text-white transition-all duration-300 ${
          isScrolled ? "bg-paco/95 backdrop-blur-sm shadow-md" : "bg-paco"
        }`}
      >
        <div className="container mx-auto px-4">
          {/* Top section with logo and buttons */}
          <div className="flex justify-between items-center py-3">
            <Link href="/" className="flex items-center">
              {/* Logo placeholder - replace with your actual logo */}
              <div className="h-12 w-40 relative flex items-center">
                {/* This is a placeholder that you can remove once you add your logo */}
                <div className="border-2 border-dashed border-white/50 w-full h-full flex items-center justify-center">
                  <span className="text-white/70 text-sm">Add your logo here</span>
                </div>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-3">
              <form onSubmit={handleHeaderSearch} className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-white/10 text-white placeholder-white/60 px-3 py-1.5 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/30 w-40 transition-all duration-300 focus:w-52"
                />
                <button type="submit" className="absolute right-2 top-1.5 h-4 w-4 text-white/60">
                  <Search className="h-4 w-4" />
                </button>
              </form>
              <a
                href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gold text-white px-4 py-2 rounded font-medium hover:bg-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 text-sm shadow-sm"
              >
                APPLY NOW
              </a>
              <button
                onClick={openVideoModal}
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-sm shadow-sm hover:shadow-md flex items-center"
              >
                <Play size={16} className="mr-1" />
                INTRODUCTORY VIDEO
              </button>
              <a
                href="https://www.sharevault.net/documents?svid=5107"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-sm shadow-sm hover:shadow-md"
              >
                SHAREVAULT
              </a>
            </div>

            <button className="md:hidden text-white" onClick={toggleMenu} aria-label="Toggle menu">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Thin white border separator */}
          <div className="border-t border-white/30"></div>

          {/* Navigation section */}
          <nav className={`${isMenuOpen ? "block" : "hidden"} md:block py-2`}>
            <ul className="flex flex-col md:flex-row md:justify-center md:space-x-4 space-y-3 md:space-y-0 items-center">
              <li>
                <Link
                  href="/"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  HOME
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/about"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/about")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={handleAboutMouseEnter}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  ABOUT US
                </Link>

                {/* About Dropdown menu */}
                <div
                  ref={aboutDropdownRef}
                  className={`absolute left-0 w-64 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transition-all duration-200 ${
                    isAboutDropdownOpen
                      ? "opacity-100 translate-y-1 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none invisible"
                  }`}
                  onMouseEnter={handleAboutMouseEnter}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  <div className="absolute -top-2 left-4 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/about"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    About Overview
                  </Link>
                  <Link
                    href="/about/case-method-teaching"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/case-method-teaching" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Case Method Teaching
                  </Link>
                  <Link
                    href="/about/professional-development"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/professional-development" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Professional Development
                  </Link>
                  <Link
                    href="/about/team"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/team" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    The Team
                  </Link>
                  <Link
                    href="/about/students"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/students" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Students
                  </Link>
                  <Link
                    href="/about/careers"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/about/careers" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Careers
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/curriculum"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/curriculum")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  CURRICULUM
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/opportunities"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/opportunities")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={handleOpportunitiesMouseEnter}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  OPPORTUNITIES FOR TEACHERS
                </Link>

                {/* Opportunities Dropdown menu */}
                <div
                  ref={opportunitiesDropdownRef}
                  className={`absolute left-0 w-64 bg-white rounded-md shadow-lg py-1 text-gray-800 z-50 transition-all duration-200 ${
                    isOpportunitiesDropdownOpen
                      ? "opacity-100 translate-y-1 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none invisible"
                  }`}
                  onMouseEnter={handleOpportunitiesMouseEnter}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  <div className="absolute -top-2 left-4 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/partners"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/partners" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Partners
                  </Link>
                  <a
                    href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block px-4 py-2 hover:bg-gray-100 hover:text-paco"
                  >
                    Apply Now
                  </a>
                  <Link
                    href="/opportunities/mailing-list"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/opportunities/mailing-list" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Join Mailing List
                  </Link>
                  <Link
                    href="/opportunities/future"
                    className={`block px-4 py-2 hover:bg-gray-100 hover:text-paco ${
                      pathname === "/opportunities/future" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Future Opportunities
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/press-videos"
                  className={`text-white font-medium px-4 py-2 rounded-md text-sm ${
                    isActive("/press-videos")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  PRESS & VIDEOS
                </Link>
              </li>
            </ul>
          </nav>

          <div className={`${isMenuOpen ? "flex" : "hidden"} md:hidden flex-col space-y-3 py-3 items-center`}>
            <form onSubmit={handleHeaderSearch} className="relative w-full mb-2">
              <input
                type="text"
                placeholder="Search..."
                className="bg-white/10 text-white placeholder-white/60 px-3 py-1.5 rounded text-sm focus:outline-none focus:ring-1 focus:ring-white/30 w-full"
              />
              <button type="submit" className="absolute right-2 top-1.5 h-4 w-4 text-white/60">
                <Search className="h-4 w-4" />
              </button>
            </form>
            <a
              href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gold text-white px-4 py-2 rounded font-medium hover:bg-cherrywood hover:shadow-[0_0_15px_rgba(102,25,21,0.7)] transition-all duration-300 w-full text-center shadow-sm"
            >
              APPLY NOW
            </a>
            <button
              onClick={openVideoModal}
              className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full shadow-sm flex items-center justify-center"
            >
              <Play size={16} className="mr-1" />
              INTRODUCTORY VIDEO
            </button>
            <a
              href="https://www.sharevault.net/documents?svid=5107"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full text-center shadow-sm"
            >
              SHAREVAULT
            </a>
          </div>
        </div>
      </header>

      {/* Modern integrated breadcrumbs */}
      {showBreadcrumbs && (
        <div className="bg-white/90 backdrop-blur-sm border-b border-gray-200 py-2 px-4 shadow-sm">
          <div className="container mx-auto">
            <ol className="flex flex-wrap items-center text-xs md:text-sm text-gray-600">
              <li className="flex items-center">
                <Link href="/" className="text-paco hover:text-cherrywood transition-colors flex items-center">
                  <Home size={12} className="mr-1" />
                  <span>Home</span>
                </Link>
              </li>

              {breadcrumbs.map((breadcrumb, index) => (
                <li key={breadcrumb.path} className="flex items-center">
                  <ChevronRight size={12} className="mx-1 text-gray-400" />
                  {index === breadcrumbs.length - 1 ? (
                    <span className="font-medium text-gray-800">{breadcrumb.name}</span>
                  ) : (
                    <Link href={breadcrumb.path} className="text-paco hover:text-cherrywood transition-colors">
                      {breadcrumb.name}
                    </Link>
                  )}
                </li>
              ))}
            </ol>
          </div>
        </div>
      )}

      {/* Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl="https://vimeo.com/1034793871?share=copy"
      />
    </div>
  )
}
