"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { BarChart, MapPin, Users, TrendingUp, School } from "lucide-react"

type StatsData = {
  totalTeachers: number
  totalCounties: number
  topStates: Array<{
    name: string
    teachers: number
    counties: number
  }>
  growth: {
    thisYear: number
    lastYear: number
    percentChange: number
  }
}

export function MapStats() {
  const [stats, setStats] = useState<StatsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API response with mock data
    const timer = setTimeout(() => {
      setStats({
        totalTeachers: 4827,
        totalCounties: 743,
        topStates: [
          { name: "California", teachers: 612, counties: 42 },
          { name: "New York", teachers: 487, counties: 38 },
          { name: "Texas", teachers: 356, counties: 67 },
          { name: "Florida", teachers: 298, counties: 45 },
          { name: "Massachusetts", teachers: 276, counties: 12 },
        ],
        growth: {
          thisYear: 4827,
          lastYear: 3941,
          percentChange: 22.5,
        },
      })
      setLoading(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-2">
            <Skeleton className="h-5 w-40" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-8 w-24" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <Skeleton className="h-5 w-40" />
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="states">By State</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-2">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Users className="h-4 w-4 mr-2" />
                Total Partner Teachers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalTeachers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Across {stats?.totalCounties.toLocaleString()} counties
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <TrendingUp className="h-4 w-4 mr-2" />
                Year-over-Year Growth
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-cherrywood">+{stats?.growth.percentChange}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats?.growth.lastYear.toLocaleString()} → {stats?.growth.thisYear.toLocaleString()} teachers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                Coverage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(((stats?.totalCounties || 0) / 3142) * 100)}%</div>
              <p className="text-xs text-muted-foreground mt-1">Of all U.S. counties</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="states" className="mt-2">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <BarChart className="h-4 w-4 mr-2" />
                Top States by Teachers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats?.topStates.map((state, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="font-medium">{i + 1}.</div>
                      <div className="ml-2">{state.name}</div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center text-sm">
                        <School className="h-3 w-3 mr-1" />
                        {state.teachers}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3 mr-1" />
                        {state.counties}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
