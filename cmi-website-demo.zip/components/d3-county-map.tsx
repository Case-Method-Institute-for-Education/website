"use client"

import { useEffect, useRef, useState } from "react"
import * as d3 from "d3"
import * as topojson from "topojson-client"

interface CountyData {
  FIPS: string
  County: string
  value1: string // Number of schools
  value2: string // Number of partner teachers
  value3: string // Number of students
}

export default function D3CountyMap() {
  const svgRef = useRef<SVGSVGElement>(null)
  const tooltipRef = useRef<HTMLDivElement>(null)
  const legendRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    if (!svgRef.current || !tooltipRef.current || !legendRef.current || !containerRef.current) return

    // Width and height of the SVG
    const width = 960
    const height = 600

    // Clear any existing content
    d3.select(svgRef.current).selectAll("*").remove()
    d3.select(legendRef.current).selectAll("*").remove()

    // Create an SVG element
    const svg = d3
      .select(svgRef.current)
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [0, 0, width, height].join(" "))
      .attr("style", "max-width: 100%; height: auto;")

    // Define a projection and a path generator
    const projection = d3
      .geoAlbersUsa()
      .scale(1280)
      .translate([width / 2, height / 2])
    const path = d3.geoPath().projection(projection)

    // Define the gold/yellow color scheme (replacing maroon)
    const goldColors = ["#fff2cc", "#ffe699", "#ffd966", "#f9cb9c", "#f6b26b", "#e69138", "#C6A158"]

    // Fixed thresholds for ranges
    const thresholds = [2, 6, 10, 16, 25, 50] // Lower bounds of each range
    const color = d3.scaleThreshold().domain(thresholds).range(goldColors)

    // Create tooltip element directly in the DOM
    const tooltip = d3
      .select(tooltipRef.current)
      .style("position", "fixed") // Changed from absolute to fixed
      .style("background-color", "white")
      .style("border", "1px solid #999")
      .style("padding", "10px")
      .style("font-size", "12px")
      .style("color", "#333")
      .style("border-radius", "4px")
      .style("pointer-events", "none")
      .style("opacity", 0)
      .style("z-index", 9999) // Ensure it's above everything
      .style("box-shadow", "0 2px 5px rgba(0,0,0,0.2)")
      .style("max-width", "200px")
      .style("transition", "opacity 0.15s ease-in-out")

    // Load the county boundaries GeoJSON (US counties in TopoJSON format)
    Promise.all([
      d3.json("https://cdn.jsdelivr.net/npm/us-atlas@3/counties-10m.json"),
      d3.csv("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/schools_2-f7jj8U5HTMGMyDa45mPgFdcJsrm1Qs.csv"),
    ])
      .then(([us, data]: [any, any[]]) => {
        // Create a map of the data by FIPS code for easier access
        const dataByFIPS: Record<string, { value: number; county: string }> = {}
        data.forEach((d: any) => {
          dataByFIPS[d.FIPS] = {
            value: +d.value2, // Only Partner Teachers
            county: d.County, // County name
          }
        })

        // Draw counties
        const counties = svg
          .append("g")
          .attr("class", "counties")
          .selectAll("path")
          .data(topojson.feature(us, us.objects.counties).features)
          .enter()
          .append("path")
          .attr("class", "county")
          .attr("d", path)
          .attr("stroke", "#fff")
          .attr("stroke-width", "0.5px")

        // Add state borders
        svg
          .append("path")
          .datum(topojson.mesh(us, us.objects.states, (a, b) => a !== b))
          .attr("class", "states")
          .attr("d", path)
          .attr("stroke", "#000")
          .attr("fill", "none")

        // Update county colors and tooltips
        counties
          .attr("fill", (d: any) => {
            const fips = d.id
            const countyData = dataByFIPS[fips]
            return countyData ? color(countyData.value) : "#f1f1f1" // Light gray for missing data
          })
          .on("mouseover", function (event: MouseEvent, d: any) {
            const fips = d.id
            const countyData = dataByFIPS[fips]

            // Highlight the county
            d3.select(this).attr("stroke", "#000").attr("stroke-width", "1.5px")

            if (countyData) {
              const value = countyData.value || "No data"
              const county = countyData.county || "Unknown county"

              // Position tooltip relative to mouse cursor in viewport
              let x = event.clientX + 10
              let y = event.clientY - 30

              // Adjust if tooltip would go off right edge of screen
              if (x + 150 > window.innerWidth) {
                x = event.clientX - 160
              }

              // Adjust if tooltip would go off bottom of screen
              if (y + 60 > window.innerHeight) {
                y = event.clientY - 70
              }

              tooltip
                .style("left", `${x}px`)
                .style("top", `${y}px`)
                .style("opacity", 1)
                .html(`<strong>${county}</strong><br>Partner Teachers: ${value}`)
            }
          })
          .on("mouseout", function () {
            // Reset county styling
            d3.select(this).attr("stroke", "#fff").attr("stroke-width", "0.5px")

            // Hide tooltip
            tooltip.style("opacity", 0)
          })
          .on("mousemove", (event: MouseEvent) => {
            // Position tooltip relative to mouse cursor in viewport
            let x = event.clientX + 10
            let y = event.clientY - 30

            // Adjust if tooltip would go off right edge of screen
            if (x + 150 > window.innerWidth) {
              x = event.clientX - 160
            }

            // Adjust if tooltip would go off bottom of screen
            if (y + 60 > window.innerHeight) {
              y = event.clientY - 70
            }

            tooltip.style("left", `${x}px`).style("top", `${y}px`)
          })

        // Add legend
        const legend = d3.select(legendRef.current)
        const rectWidth = 60 // Width of each rectangle
        const rectHeight = 20 // Height of each rectangle

        // Add title above the legend
        legend
          .append("text")
          .attr("class", "legend-title")
          .attr("x", (rectWidth * goldColors.length) / 2) // Centered
          .attr("y", 15) // Position above the rectangles
          .attr("text-anchor", "middle")
          .attr("font-size", "14px")
          .attr("font-weight", "bold")
          .text("CMI Partner Teachers by County")

        // Custom legend labels
        const legendLabels = [
          "1", // First range
          "2-5", // Second range
          "6-9", // Third range
          "10-15", // Fourth range
          "16-24", // Fifth range
          "25-49", // Sixth range
          "50+", // Seventh range
        ]

        // Draw legend rectangles and labels
        legendLabels.forEach((label, i) => {
          // Add rectangles
          legend
            .append("rect")
            .attr("x", i * rectWidth)
            .attr("y", 30) // Below the title
            .attr("width", rectWidth)
            .attr("height", rectHeight)
            .attr("fill", goldColors[i])
            .attr("stroke", "#ccc")
            .attr("stroke-width", "0.5px")

          // Add labels
          legend
            .append("text")
            .attr("x", i * rectWidth + rectWidth / 2)
            .attr("y", 30 + rectHeight + 20) // Position below the rectangles with extra padding
            .attr("text-anchor", "middle")
            .attr("font-size", "12px")
            .text(label)
        })

        // Adjust legend width dynamically
        legend.attr("width", rectWidth * legendLabels.length).attr("height", 80) // Increased height to avoid clipping

        // Mark as loaded
        setIsLoaded(true)
      })
      .catch((error) => {
        console.error("Error loading map data:", error)
      })

    // Cleanup function
    return () => {
      d3.select(svgRef.current).selectAll("*").remove()
      d3.select(legendRef.current).selectAll("*").remove()
    }
  }, [])

  return (
    <div className="d3-map-container" ref={containerRef}>
      <svg ref={svgRef} className="d3-map"></svg>
      {/* Tooltip is positioned fixed relative to viewport */}
      <div ref={tooltipRef} className="county-tooltip" aria-hidden="true"></div>
      <div className="legend-container" style={{ margin: "20px auto", display: "inline-block" }}>
        <svg ref={legendRef} className="legend" height="100"></svg>
      </div>
      {/* Add loading indicator */}
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/50">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-paco"></div>
        </div>
      )}
    </div>
  )
}
