"use client"

import { useState, useEffect } from "react"
import { Play } from "lucide-react"
import VideoModal from "./video-modal"

interface TestimonialCardProps {
  name: string
  location: string
  description: string
  videoUrl: string
  thumbnail?: string
}

export default function TestimonialCard({ name, location, description, videoUrl, thumbnail }: TestimonialCardProps) {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [vimeoThumbnail, setVimeoThumbnail] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Function to extract Vimeo ID from URL
    const getVimeoId = (url: string) => {
      const regexes = [
        /vimeo\.com\/(\d+)/, // vimeo.com/1234567
        /vimeo\.com\/.*?\/(\d+)/, // vimeo.com/channels/staffpicks/1234567
        /vimeo\.com\/.*?\?v=(\d+)/, // vimeo.com/video?v=1234567
        /vimeo\.com\/.*?\?share=copy/, // vimeo.com/1034793871?share=copy
      ]

      for (const regex of regexes) {
        const match = url.match(regex)
        if (match) {
          // For URLs with ?share=copy, extract the ID from the URL path
          if (match[0].includes("?share=copy")) {
            const pathMatch = url.match(/vimeo\.com\/(\d+)\?/)
            return pathMatch ? pathMatch[1] : ""
          }
          return match[1]
        }
      }
      return ""
    }

    const fetchVimeoThumbnail = async () => {
      try {
        setIsLoading(true)
        const vimeoId = getVimeoId(videoUrl)
        if (!vimeoId) {
          console.error("Could not extract Vimeo ID from URL:", videoUrl)
          setIsLoading(false)
          return
        }

        // Use Vimeo's oEmbed API to get video information including thumbnail
        const response = await fetch(`https://vimeo.com/api/oembed.json?url=https://vimeo.com/${vimeoId}`)
        const data = await response.json()

        if (data && data.thumbnail_url) {
          // Get a larger thumbnail by modifying the URL
          const largerThumbnail = data.thumbnail_url.replace("_295x166", "_640x360")
          setVimeoThumbnail(largerThumbnail)
        }
      } catch (error) {
        console.error("Error fetching Vimeo thumbnail:", error)
      } finally {
        setIsLoading(false)
      }
    }

    // Only fetch if no custom thumbnail is provided
    if (!thumbnail) {
      fetchVimeoThumbnail()
    } else {
      setIsLoading(false)
    }
  }, [videoUrl, thumbnail])

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  // Use custom thumbnail if provided, otherwise use Vimeo thumbnail or placeholder
  const displayThumbnail = thumbnail || vimeoThumbnail || "/placeholder.svg?height=300&width=400"

  return (
    <>
      <div
        className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300"
        onClick={openVideoModal}
      >
        <div className="relative bg-gray-200 h-64">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
              <div className="animate-pulse w-full h-full bg-gray-300"></div>
            </div>
          ) : (
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${displayThumbnail})` }}
            >
              <div className="absolute inset-0 bg-black/30 hover:bg-black/50 transition-colors flex items-center justify-center">
                <div className="bg-paco hover:bg-cherrywood transition-colors rounded-full p-4">
                  <Play className="h-8 w-8 text-white" />
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="p-6">
          <h3 className="text-xl font-bold text-paco mb-1">{name}</h3>
          <p className="text-gray-600 mb-4">{location}</p>
          <p className="text-gray-700">{description}</p>
        </div>
      </div>

      <VideoModal isOpen={isVideoModalOpen} onClose={closeVideoModal} videoUrl={videoUrl} />
    </>
  )
}
