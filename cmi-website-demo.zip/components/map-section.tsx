"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import D3CountyMap from "./d3-county-map"

export default function MapSection() {
  const [stats] = useState({
    totalTeachers: 4827,
    totalStudents: 213525,
    totalStates: 48,
    totalSchools: 1236,
  })

  return (
    <section className="py-16 bg-gray-50 relative overflow-hidden">
      <div className="container mx-auto px-4 max-w-6xl">
        <h2 className="text-3xl font-bold text-paco mb-6 text-center">Our National Network</h2>
        <p className="text-gray-700 text-center max-w-3xl mx-auto mb-12">
          The Case Method Institute works with teachers across the United States, providing free professional
          development, curriculum materials, and ongoing support.
        </p>

        <div className="grid md:grid-cols-4 gap-4 mb-12">
          <Card className="bg-white shadow-sm">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-paco">{stats.totalTeachers.toLocaleString()}</div>
              <div className="text-sm text-gray-600 mt-1">Partner Teachers</div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-paco">{stats.totalStudents.toLocaleString()}</div>
              <div className="text-sm text-gray-600 mt-1">Students Reached</div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-paco">{stats.totalStates}</div>
              <div className="text-sm text-gray-600 mt-1">States</div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-paco">{stats.totalSchools.toLocaleString()}</div>
              <div className="text-sm text-gray-600 mt-1">Schools</div>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8 relative">
          <div className="bg-white rounded-lg shadow-sm border p-4 overflow-visible">
            <D3CountyMap />
          </div>
        </div>
      </div>
    </section>
  )
}
