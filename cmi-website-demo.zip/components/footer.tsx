import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-paco text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-12">
          <div className="flex flex-col items-center md:items-start">
            {/* Logo placeholder - replace with your actual logo */}
            <div className="h-16 w-48 relative flex items-center mb-4">
              {/* You can uncomment and modify this when you have your logo */}
              {/* <Image 
                src="/your-logo.png" 
                alt="Case Method Institute" 
                fill 
                style={{ objectFit: 'contain' }} 
                className="max-h-full" 
              /> */}

              {/* This is a placeholder that you can remove once you add your logo */}
              <div className="border-2 border-dashed border-white/50 w-full h-full flex items-center justify-center">
                <span className="text-white/70 text-sm">Add your logo here</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Contact Information</h3>
            <p className="mb-4">
              Case Method Institute
              <br />
              for Education and Democracy
              <br />
              <br />8 Story Street Suite 100
              <br />
              Cambridge, MA 02138
              <br />
              Phone: 1.617.495.0458
              <br />
            </p>
            <Link href="/contact" className="text-white hover:underline">
              Contact us
            </Link>
            <div className="mt-6">
              <a
                href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6ileiXadIpSDeaW"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-gold transition-colors inline-block"
              >
                JOIN OUR MAILING LIST
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:underline">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:underline">
                  About
                </Link>
              </li>
              <li>
                <Link href="/curriculum" className="hover:underline">
                  Curriculum
                </Link>
              </li>
              <li>
                <Link href="/partners" className="hover:underline">
                  Partners
                </Link>
              </li>
              <li>
                <Link href="/apply" className="hover:underline">
                  Apply
                </Link>
              </li>
              <li>
                <Link href="/careers" className="hover:underline">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/press-videos" className="hover:underline">
                  Press & Videos
                </Link>
              </li>
            </ul>
            <div className="mt-6">
              <a
                href="/donate"
                className="bg-navy text-white px-4 py-2 rounded font-medium hover:bg-gold transition-colors inline-block"
              >
                MAKE A GIFT
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-white/20 py-4">
        <div className="container mx-auto px-4 text-center">
          <p className="text-white/70">
            Copyright © {new Date().getFullYear()} Case Method Institute for Education and Democracy
          </p>
        </div>
      </div>
    </footer>
  )
}
