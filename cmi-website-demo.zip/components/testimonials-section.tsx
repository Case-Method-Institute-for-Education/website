"use client"

import { useState } from "react"
import VideoModal from "./video-modal"
import TestimonialCard from "./testimonial-card"
import FeaturedTestimonial from "@/components/featured-testimonial"

type Testimonial = {
  id: number
  name: string
  location: string
  description: string
  videoUrl: string
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Eleanor Cannon",
    location: "Houston, TX",
    description: "Eleanor Cannon describes her students' reactions to the case method.",
    videoUrl: "https://vimeo.com/1034792891?share=copy",
  },
  {
    id: 2,
    name: "Maureen O'Hern",
    location: "Dorchester, MA",
    description: "Maureen O'Hern describes how the case method transformed her classroom.",
    videoUrl: "https://vimeo.com/1034794729?share=copy",
  },
  {
    id: 3,
    name: "Michael Gordon",
    location: "Munster, IN",
    description: "Michael Gordon describes why he would recommend the case method to other teachers.",
    videoUrl: "https://vimeo.com/1034795442?share=copy",
  },
]

export default function TestimonialsSection() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [currentVideoUrl, setCurrentVideoUrl] = useState("")

  const openVideoModal = (url: string) => {
    setCurrentVideoUrl(url)
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-paco mb-12 text-center">Teacher Testimonials</h2>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <TestimonialCard
              key={testimonial.id}
              name={testimonial.name}
              location={testimonial.location}
              description={testimonial.description}
              videoUrl={testimonial.videoUrl}
            />
          ))}
        </div>

        <FeaturedTestimonial
          name="Rhonda Feder"
          location="Teacher, Philadelphia, PA"
          quote="I have had few weeks in teaching that I enjoyed as much as doing this case....My biggest dilemma now is how many cases I want to fit into the year."
          videoUrl="https://vimeo.com/1034793871?share=copy"
        />
      </div>
      <VideoModal isOpen={isVideoModalOpen} onClose={closeVideoModal} videoUrl={currentVideoUrl} />
    </section>
  )
}
