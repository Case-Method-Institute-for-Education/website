type NewsItem = {
  id: number
  title: string
  date: string
  source: string
  excerpt: string
  url: string
}

const newsItems: NewsItem[] = [
  {
    id: 1,
    title: "A Better Way to Teach History",
    date: "8 FEB 2016",
    source: "The Atlantic",
    excerpt:
      "One professor is borrowing a method from Harvard Business School to engage students and inspire better decision-making skills.",
    url: "https://www.theatlantic.com/education/archive/2016/02/harvard-history-class/460314/",
  },
  {
    id: 2,
    title: "Rewriting History",
    date: "2 MAR 2016",
    source: "HBS Alumni Bulletin",
    excerpt: "Can one HBS professor change how American history is taught in high schools?",
    url: "https://www.alumni.hbs.edu/stories/Pages/story-impact.aspx?num=5151",
  },
  {
    id: 3,
    title: "All Hail Partisan Politics",
    date: "9 FEB 2017",
    source: "Harvard Gazette",
    excerpt:
      "David Moss spoke with the Gazette about the book and about a new initiative to bring his case studies into dozens of high school classrooms, where they're used as an interactive teaching tool.",
    url: "https://news.harvard.edu/gazette/story/2017/02/all-hail-partisan-politics/",
  },
  {
    id: 4,
    title: "How to Teach Civics in School",
    date: "6 JUL 2017",
    source: "The Economist",
    excerpt:
      'Inspired by his years using the "case method" developed by Harvard Business School, David Moss has adapted the approach to the study of American democracy.',
    url: "https://www.economist.com/blogs/democracyinamerica/2017/07/civics-lessons",
  },
]

export default function NewsSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-paco mb-12 text-center">In the News</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {newsItems.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="bg-gray-200 h-48"></div>
              <div className="p-6">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xl font-bold text-paco hover:text-cherrywood transition-colors block mb-2"
                >
                  {item.title}
                </a>
                <p className="text-sm text-gray-500 mb-4">
                  {item.date} | {item.source}
                </p>
                <p className="text-gray-700">{item.excerpt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
