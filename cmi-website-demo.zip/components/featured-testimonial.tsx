"use client"

import { useState, useEffect } from "react"
import { Play } from "lucide-react"
import VideoModal from "./video-modal"

interface FeaturedTestimonialProps {
  name: string
  location: string
  quote: string
  videoUrl: string
  customThumbnail?: string
}

export default function FeaturedTestimonial({
  name,
  location,
  quote,
  videoUrl,
  customThumbnail,
}: FeaturedTestimonialProps) {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [thumbnail, setThumbnail] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Function to extract Vimeo ID from URL
    const getVimeoId = (url: string) => {
      const regexes = [
        /vimeo\.com\/(\d+)/, // vimeo.com/1234567
        /vimeo\.com\/.*?\/(\d+)/, // vimeo.com/channels/staffpicks/1234567
        /vimeo\.com\/.*?\?v=(\d+)/, // vimeo.com/video?v=1234567
        /vimeo\.com\/.*?\?share=copy/, // vimeo.com/1034793871?share=copy
      ]

      for (const regex of regexes) {
        const match = url.match(regex)
        if (match) {
          // For URLs with ?share=copy, extract the ID from the URL path
          if (match[0].includes("?share=copy")) {
            const pathMatch = url.match(/vimeo\.com\/(\d+)\?/)
            return pathMatch ? pathMatch[1] : ""
          }
          return match[1]
        }
      }
      return ""
    }

    const fetchVimeoThumbnail = async () => {
      try {
        setIsLoading(true)
        const vimeoId = getVimeoId(videoUrl)
        if (!vimeoId) {
          console.error("Could not extract Vimeo ID from URL:", videoUrl)
          setIsLoading(false)
          return
        }

        // Use Vimeo's oEmbed API to get video information including thumbnail
        const response = await fetch(`https://vimeo.com/api/oembed.json?url=https://vimeo.com/${vimeoId}`)
        const data = await response.json()

        if (data && data.thumbnail_url) {
          // Get a larger thumbnail by modifying the URL
          const largerThumbnail = data.thumbnail_url.replace("_295x166", "_640x360")
          setThumbnail(largerThumbnail)
        }
      } catch (error) {
        console.error("Error fetching Vimeo thumbnail:", error)
      } finally {
        setIsLoading(false)
      }
    }

    // Only fetch if no custom thumbnail is provided
    if (!customThumbnail) {
      fetchVimeoThumbnail()
    } else {
      setThumbnail(customThumbnail)
      setIsLoading(false)
    }
  }, [videoUrl, customThumbnail])

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  // Use custom thumbnail if provided, otherwise use Vimeo thumbnail or placeholder
  const displayThumbnail = customThumbnail || thumbnail || "/placeholder.svg?height=300&width=400"

  return (
    <>
      <div className="bg-navy text-white p-8 rounded-lg max-w-5xl mx-auto border-l-4 border-gold">
        <div className="md:flex items-center">
          <div className="md:w-2/3 mb-6 md:mb-0 md:pr-8">
            <h3 className="text-2xl font-normal italic mb-4">
              <span className="text-3xl">"</span>
              {quote}
              <span className="text-3xl">"</span>
            </h3>
            <p className="text-xl font-semibold">{name}</p>
            <p className="text-white/80">{location}</p>
            <div className="text-center md:text-left mt-6">
              <button
                onClick={openVideoModal}
                className="bg-white text-navy hover:bg-gold hover:text-white px-6 py-3 rounded font-medium transition-colors inline-flex items-center"
              >
                <Play className="h-5 w-5 mr-2" />
                WATCH INTRODUCTORY VIDEO
              </button>
            </div>
          </div>
          <div className="md:w-1/3 relative h-64 rounded-lg overflow-hidden">
            {isLoading ? (
              <div className="absolute inset-0 bg-gray-700 animate-pulse"></div>
            ) : (
              <div
                className="absolute inset-0 bg-cover bg-center cursor-pointer"
                style={{ backgroundImage: `url(${displayThumbnail})` }}
                onClick={openVideoModal}
              >
                <div className="absolute inset-0 bg-black/20 hover:bg-black/30 transition-colors"></div>
              </div>
            )}
          </div>
        </div>
      </div>

      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl={videoUrl}
        thumbnail={displayThumbnail}
      />
    </>
  )
}
