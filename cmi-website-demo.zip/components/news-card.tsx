interface NewsCardProps {
  title: string
  date: string
  source: string
  excerpt?: string
  url: string
  thumbnail?: string
}

export default function NewsCard({ title, date, source, excerpt, url, thumbnail }: NewsCardProps) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-all duration-300 block h-full"
    >
      {thumbnail && (
        <div
          className="h-48 w-full bg-cover bg-center"
          style={{
            backgroundImage: `url(${thumbnail || `/placeholder.svg?height=300&width=400&text=${encodeURIComponent(source)}`})`,
          }}
          role="img"
          aria-label={`${title} thumbnail`}
        ></div>
      )}
      <div className="p-6">
        <h3 className="text-xl font-bold text-paco hover:text-cherrywood transition-colors mb-2">{title}</h3>
        <p className="text-sm text-gray-500 mb-4">
          {date} | {source}
        </p>
        {excerpt && <p className="text-gray-700">{excerpt}</p>}
      </div>
    </a>
  )
}
