import Link from "next/link"

type AboutSidebarProps = {
  activePage: "overview" | "case-method" | "professional-development" | "team" | "students" | "careers"
}

export default function AboutSidebar({ activePage }: AboutSidebarProps) {
  return (
    <div className="rounded-lg overflow-hidden shadow-sm">
      <div className="p-4 bg-paco text-white">
        <h3 className="font-medium text-lg">About Us</h3>
      </div>
      <nav className="bg-white">
        <Link
          href="/about"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "overview" ? "border-paco text-paco font-medium" : "border-transparent text-gray-600"
          }`}
        >
          About Overview
        </Link>
        <Link
          href="/about/case-method-teaching"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "case-method" ? "border-paco text-paco font-medium" : "border-transparent text-gray-600"
          }`}
        >
          Case Method Teaching
        </Link>
        <Link
          href="/about/professional-development"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "professional-development"
              ? "border-paco text-paco font-medium"
              : "border-transparent text-gray-600"
          }`}
        >
          Professional Development
        </Link>
        <Link
          href="/about/team"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "team" ? "border-paco text-paco font-medium" : "border-transparent text-gray-600"
          }`}
        >
          The Team
        </Link>
        <Link
          href="/about/students"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "students" ? "border-paco text-paco font-medium" : "border-transparent text-gray-600"
          }`}
        >
          Students
        </Link>
        <Link
          href="/about/careers"
          className={`block px-5 py-3 hover:bg-gray-50 transition-colors border-l-4 ${
            activePage === "careers" ? "border-paco text-paco font-medium" : "border-transparent text-gray-600"
          }`}
        >
          Careers
        </Link>
      </nav>
    </div>
  )
}
