"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Play } from "lucide-react"
import VideoModal from "./video-modal"

interface VideoCardProps {
  id: number
  title: string
  videoUrl: string
  onClick?: () => void
}

export default function VideoCard({ id, title, videoUrl, onClick }: VideoCardProps) {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [thumbnail, setThumbnail] = useState<string>("/placeholder.svg?height=300&width=400")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Function to extract Vimeo ID from URL
    const getVimeoId = (url: string) => {
      const regexes = [
        /vimeo\.com\/(\d+)/, // vimeo.com/1234567
        /vimeo\.com\/.*?\/(\d+)/, // vimeo.com/channels/staffpicks/1234567
        /vimeo\.com\/.*?\?v=(\d+)/, // vimeo.com/video?v=1234567
        /vimeo\.com\/.*?\?share=copy/, // vimeo.com/1034793871?share=copy
      ]

      for (const regex of regexes) {
        const match = url.match(regex)
        if (match) {
          // For URLs with ?share=copy, extract the ID from the URL path
          if (match[0].includes("?share=copy")) {
            const pathMatch = url.match(/vimeo\.com\/(\d+)\?/)
            return pathMatch ? pathMatch[1] : ""
          }
          return match[1]
        }
      }
      return ""
    }

    const fetchVimeoThumbnail = async () => {
      try {
        setIsLoading(true)
        const vimeoId = getVimeoId(videoUrl)
        if (!vimeoId) {
          console.error("Could not extract Vimeo ID from URL:", videoUrl)
          setIsLoading(false)
          return
        }

        // Use Vimeo's oEmbed API to get video information including thumbnail
        const response = await fetch(`https://vimeo.com/api/oembed.json?url=https://vimeo.com/${vimeoId}`)
        const data = await response.json()

        if (data && data.thumbnail_url) {
          // Get a larger thumbnail by modifying the URL
          const largerThumbnail = data.thumbnail_url.replace("_295x166", "_640x360")
          setThumbnail(largerThumbnail)
        }
      } catch (error) {
        console.error("Error fetching Vimeo thumbnail:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchVimeoThumbnail()
  }, [videoUrl])

  const openVideoModal = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  return (
    <>
      <div
        className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300"
        onClick={onClick || openVideoModal}
      >
        <div className="relative bg-gray-200 h-48">
          {/* Thumbnail with loading state */}
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
              <div className="animate-pulse w-full h-full bg-gray-300"></div>
            </div>
          ) : (
            <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${thumbnail})` }}>
              <div className="absolute inset-0 bg-black/30 hover:bg-black/50 transition-colors flex items-center justify-center">
                <button
                  onClick={openVideoModal}
                  className="bg-white rounded-full p-3 hover:bg-gray-100 transition-colors"
                  aria-label={`Play video: ${title}`}
                >
                  <Play className="h-6 w-6 text-paco" />
                </button>
              </div>
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="text-lg font-bold text-paco">{title}</h3>
        </div>
      </div>

      <VideoModal isOpen={isVideoModalOpen} onClose={closeVideoModal} videoUrl={videoUrl} />
    </>
  )
}
