"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Search, Play } from "lucide-react"
import VideoModal from "./video-modal"

export default function HeaderLarge() {
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false)
  const [isOpportunitiesDropdownOpen, setIsOpportunitiesDropdownOpen] = useState(false)
  const [aboutDropdownTimeout, setAboutDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [opportunitiesDropdownTimeout, setOpportunitiesDropdownTimeout] = useState<NodeJS.Timeout | null>(null)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      // For header transparency effect
      if (window.scrollY > 20) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
      if (aboutDropdownTimeout) clearTimeout(aboutDropdownTimeout)
      if (opportunitiesDropdownTimeout) clearTimeout(opportunitiesDropdownTimeout)
    }
  }, [aboutDropdownTimeout, opportunitiesDropdownTimeout])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  const handleAboutMouseEnter = () => {
    if (aboutDropdownTimeout) {
      clearTimeout(aboutDropdownTimeout)
      setAboutDropdownTimeout(null)
    }
    setIsAboutDropdownOpen(true)
  }

  const handleAboutMouseLeave = () => {
    setAboutDropdownTimeout(
      setTimeout(() => {
        setIsAboutDropdownOpen(false)
      }, 100),
    )
  }

  const handleOpportunitiesMouseEnter = () => {
    if (opportunitiesDropdownTimeout) {
      clearTimeout(opportunitiesDropdownTimeout)
      setOpportunitiesDropdownTimeout(null)
    }
    setIsOpportunitiesDropdownOpen(true)
  }

  const handleOpportunitiesMouseLeave = () => {
    setOpportunitiesDropdownTimeout(
      setTimeout(() => {
        setIsOpportunitiesDropdownOpen(false)
      }, 100),
    )
  }

  // Check if a link is active
  const isActive = (path: string) => {
    if (path === "/") {
      return pathname === path
    }
    return pathname.startsWith(path)
  }

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 text-white transition-all duration-300 ${
          isScrolled ? "bg-paco/95 backdrop-blur-sm shadow-md" : "bg-paco"
        }`}
      >
        <div className="container mx-auto px-4">
          {/* Top section with logo and buttons - LARGER */}
          <div className="flex justify-between items-center py-5">
            <Link href="/" className="flex items-center">
              {/* Logo placeholder - larger size */}
              <div className="h-16 w-52 relative flex items-center">
                <div className="border-2 border-dashed border-white/50 w-full h-full flex items-center justify-center">
                  <span className="text-white/70 text-base">Add your logo here</span>
                </div>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-white/10 text-white placeholder-white/60 px-4 py-2.5 rounded text-base focus:outline-none focus:ring-1 focus:ring-white/30 w-48 transition-all duration-300 focus:w-64"
                />
                <Search className="absolute right-3 top-2.5 h-5 w-5 text-white/60" />
              </div>
              <button
                onClick={openVideoModal}
                className="bg-navy text-white px-5 py-3 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-base shadow-sm hover:shadow-md flex items-center"
              >
                <Play size={18} className="mr-2" />
                INTRODUCTORY VIDEO
              </button>
              <a
                href="https://www.sharevault.net/documents?svid=5107"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy text-white px-5 py-3 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors text-base shadow-sm hover:shadow-md"
              >
                SHAREVAULT
              </a>
            </div>

            <button className="md:hidden text-white" onClick={toggleMenu} aria-label="Toggle menu">
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>

          {/* Thicker white border separator */}
          <div className="border-t-2 border-white/40"></div>

          {/* Navigation section - LARGER */}
          <nav className={`${isMenuOpen ? "block" : "hidden"} md:block py-4`}>
            <ul className="flex flex-col md:flex-row md:justify-center md:space-x-6 space-y-4 md:space-y-0 items-center">
              <li>
                <Link
                  href="/"
                  className={`text-white font-medium px-6 py-3 rounded-md text-base ${
                    isActive("/")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  HOME
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/about"
                  className={`text-white font-medium px-6 py-3 rounded-md text-base ${
                    isActive("/about")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={handleAboutMouseEnter}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  ABOUT US
                </Link>

                {/* About Dropdown menu */}
                <div
                  className={`absolute left-0 w-72 bg-white rounded-md shadow-lg py-2 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                    isAboutDropdownOpen
                      ? "opacity-100 translate-y-2 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none"
                  }`}
                  onMouseEnter={handleAboutMouseEnter}
                  onMouseLeave={handleAboutMouseLeave}
                >
                  <div className="absolute -top-2 left-6 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/about"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    About Overview
                  </Link>
                  <Link
                    href="/about/case-method-teaching"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about/case-method-teaching" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Case Method Teaching
                  </Link>
                  <Link
                    href="/about/professional-development"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about/professional-development" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Professional Development
                  </Link>
                  <Link
                    href="/about/team"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about/team" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    The Team
                  </Link>
                  <Link
                    href="/about/students"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about/students" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Students
                  </Link>
                  <Link
                    href="/about/careers"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/about/careers" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Careers
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/curriculum"
                  className={`text-white font-medium px-6 py-3 rounded-md text-base ${
                    isActive("/curriculum")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  CURRICULUM
                </Link>
              </li>
              <li className="relative group">
                <Link
                  href="/opportunities"
                  className={`text-white font-medium px-6 py-3 rounded-md text-base ${
                    isActive("/opportunities")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                  onMouseEnter={handleOpportunitiesMouseEnter}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  OPPORTUNITIES FOR TEACHERS
                </Link>

                {/* Opportunities Dropdown menu */}
                <div
                  className={`absolute left-0 w-72 bg-white rounded-md shadow-lg py-2 text-gray-800 z-50 transform transition-all duration-300 ease-in-out ${
                    isOpportunitiesDropdownOpen
                      ? "opacity-100 translate-y-2 pointer-events-auto"
                      : "opacity-0 -translate-y-1 pointer-events-none"
                  }`}
                  onMouseEnter={handleOpportunitiesMouseEnter}
                  onMouseLeave={handleOpportunitiesMouseLeave}
                >
                  <div className="absolute -top-2 left-6 w-4 h-4 bg-white transform rotate-45"></div>
                  <Link
                    href="/partners"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/partners" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Partners
                  </Link>
                  <a
                    href="https://cmi.iad1.qualtrics.com/jfe/form/SV_6nG8R030HSuLotU"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base"
                  >
                    Apply Now
                  </a>
                  <Link
                    href="/opportunities/mailing-list"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/opportunities/mailing-list" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Join Mailing List
                  </Link>
                  <Link
                    href="/opportunities/future"
                    className={`block px-5 py-2.5 hover:bg-gray-100 hover:text-paco text-base ${
                      pathname === "/opportunities/future" ? "bg-gray-100 text-paco" : ""
                    }`}
                  >
                    Future Opportunities
                  </Link>
                </div>
              </li>
              <li>
                <Link
                  href="/press-videos"
                  className={`text-white font-medium px-6 py-3 rounded-md text-base ${
                    isActive("/press-videos")
                      ? "bg-navy/60 shadow-inner"
                      : "bg-navy/30 hover:bg-navy/80 hover:text-gold shadow-sm hover:shadow-md"
                  } transition-all duration-200 inline-block`}
                >
                  PRESS & VIDEOS
                </Link>
              </li>
            </ul>
          </nav>

          <div className={`${isMenuOpen ? "flex" : "hidden"} md:hidden flex-col space-y-4 py-4 items-center`}>
            <div className="relative w-full mb-2">
              <input
                type="text"
                placeholder="Search..."
                className="bg-white/10 text-white placeholder-white/60 px-4 py-2.5 rounded text-base focus:outline-none focus:ring-1 focus:ring-white/30 w-full"
              />
              <Search className="absolute right-3 top-2.5 h-5 w-5 text-white/60" />
            </div>
            <button
              onClick={openVideoModal}
              className="bg-navy text-white px-5 py-3 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full shadow-sm flex items-center justify-center"
            >
              <Play size={18} className="mr-2" />
              INTRODUCTORY VIDEO
            </button>
            <a
              href="https://www.sharevault.net/documents?svid=5107"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-navy text-white px-5 py-3 rounded font-medium hover:bg-navy/90 hover:text-gold transition-colors w-full text-center shadow-sm"
            >
              SHAREVAULT
            </a>
          </div>
        </div>
      </header>

      {/* Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={closeVideoModal}
        videoUrl="https://vimeo.com/1034793871?share=copy"
      />
    </>
  )
}
