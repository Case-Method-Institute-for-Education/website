"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { X } from "lucide-react"

interface VideoModalProps {
  isOpen: boolean
  onClose: () => void
  videoUrl: string
  thumbnail?: string
}

export default function VideoModal({ isOpen, onClose, videoUrl, thumbnail }: VideoModalProps) {
  const modalRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Handle escape key press to close modal
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
      // Prevent scrolling when modal is open
      document.body.style.overflow = "hidden"
    }

    return () => {
      document.removeEventListener("keydown", handleEscape)
      document.body.style.overflow = "auto"
    }
  }, [isOpen, onClose])

  // Handle click outside to close
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
      onClose()
    }
  }

  // Update the getVimeoId function to handle more URL formats
  const getVimeoId = (url: string) => {
    // Handle various Vimeo URL formats
    const regexes = [
      /vimeo\.com\/(\d+)/, // vimeo.com/1234567
      /vimeo\.com\/.*?\/(\d+)/, // vimeo.com/channels/staffpicks/1234567
      /vimeo\.com\/.*?\?v=(\d+)/, // vimeo.com/video?v=1234567
      /vimeo\.com\/.*?\?share=copy/, // vimeo.com/1034793871?share=copy
    ]

    for (const regex of regexes) {
      const match = url.match(regex)
      if (match) {
        // For URLs with ?share=copy, extract the ID from the URL path
        if (match[0].includes("?share=copy")) {
          const pathMatch = url.match(/vimeo\.com\/(\d+)\?/)
          return pathMatch ? pathMatch[1] : ""
        }
        return match[1]
      }
    }

    return ""
  }

  const vimeoId = getVimeoId(videoUrl)

  if (!isOpen) return null

  const handleIframeLoad = () => {
    setIsLoading(false)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
      onClick={handleBackdropClick}
    >
      <div ref={modalRef} className="relative bg-white rounded-lg shadow-xl w-full max-w-4xl mx-4">
        <button
          onClick={onClose}
          className="absolute -top-12 right-0 text-white hover:text-gold transition-colors p-2 rounded-full"
          aria-label="Close video"
        >
          <X size={24} />
        </button>
        <div className="sr-only" aria-live="polite">
          Video player opened
        </div>

        <div className="aspect-w-16 aspect-h-9 w-full">
          <div className="relative w-full h-full">
            {isLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900 rounded-lg">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
              </div>
            )}
            <iframe
              src={`https://player.vimeo.com/video/${vimeoId}?autoplay=1&title=0&byline=0&portrait=0`}
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              className="w-full h-full rounded-lg"
              onLoad={handleIframeLoad}
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  )
}
